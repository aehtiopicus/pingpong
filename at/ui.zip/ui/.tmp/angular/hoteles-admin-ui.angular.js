/*! hoteles-admin-ui - v2.80.0 - 2016-04-25\\n  * Copyright (c) 2016  Avantrip; Licensed  *//*
(function() {

Avantrip.register('hoteles-admin-ui-mainAngularApp', {})
		.on('loadMainAngularComponents', 
                                    function(angularApp) {
                                               loadAngularComponents(angularApp, Avantrip.getConfig())
                });

*/

function loadHotelesAdminUIAngularComponents( angularApp ) {
 


(function(){
    'use strict';

  angularApp.controller('AlertMessageController', function ($scope) {
  $scope.alerts = [];
/*types : 'danger' , 'success','warning'*/
  $scope.addAlert = function(alert) {
    // alert = { type: 'warning',
    //   msg:'Error !!!!!!!!!!!!!!!'};
    if($scope.alerts.length === 0){
      $scope.alerts.push(alert);
    }
  };

  $scope.closeAlert = function(index) {
    $scope.alerts.splice(index, 1);
  };

  $scope.$on('new_alert', function(event, alert) {
    $scope.addAlert(alert);
  });

  $scope.$on('close_alerts', function() {
    $scope.alerts = [];
  });

  $scope.$on('close_alert', function(event, index) {
    $scope.closeAlert(index);
  });

  });
})();

(function(){

    'use strict';

	angularApp.controller({'HotelesDestacadosController': 
        function(HotelesDestacadosService, HaloService, CRUDService,$scope) {			

            var getInput=function(input){
                  return  HaloService.getHotelList({
                     'limit' : 10,
                     'offset' : 0,
                     'name' : input,
                     'completenessFrom' : 0,
                     'completenessTo' : 100
                  }).$promise.then(function(data){

                    if (data.length === 0) {
                      var noResults = {'code':-1, 'hotelName' : 'No hay hoteles'};
                      data.push(noResults);  
                    }

                    return data;
                  });
            };

            var autocomplete = {'name':'autocompleteHotel',
                              'getInput':getInput,
                              'key':'code',
                              'value':'hotelName',
                              'firstValue':'code'};

			      var date = {'name':'date',
                        'format':'yyyy-MM-dd'};	

    	  	$scope.columns =  [ {'name':'Hotel',
                                  'id':'hotelName',
                                  'type' : autocomplete, 
                                  'bind' : 'hotelId',
                                  'editMode' : 'readOnly'
                                },           
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];

         $scope.crudOperations =new CRUDService(HotelesDestacadosService,'ruleId');          
        }
	});

})();
            

(function(){
    'use strict';
    angularApp.controller('PreferenciaHotelesController', function($scope,CRUDService,CompetenciaService,PrioridadService,ConfigService){

        $scope.configService = new CRUDService(ConfigService);
        $scope.competenciaService = new CRUDService(CompetenciaService);
        $scope.prioridadService = new CRUDService(PrioridadService);

        $scope.selPriority = {};
        $scope.selCompetition = [];

        $scope.loading = false;

        $scope.activeConfig = {
            loaded: false,
            active: false
        };

        //Paso el array a un objeto
        $scope.competitionProviders = function(arr){
            var obj = arr.split('|').map(function(e){
                return {name: e};
            });
            return obj;
        };

        //Listado de properties
        $scope.configService.onListAllObjects(
            function(object, message) {
                $scope.haloConfigs = object.configs;
                console.log('Exito:',message);
            },
            function(message) {
                console.log('Error:',message);
            });

        //Listar property seleccionada
        $scope.selectConfig = function() {
            $scope.activeConfig.loaded = false;
            $scope.loading = true;

            $scope.configService.onList(
                function(object, message) {
                    console.log('Exito:',message);

                    $scope.selCompetition = object.values['Configurations.Competition.do-providers-competition'].value;
                    $scope.selPriority = $scope.competitionProviders(object.values['Configurations.Competition.providers-competition-priority'].value);
                    $scope.providers = angular.copy($scope.selPriority);

                    $scope.activeConfig.loaded = true;
                    $scope.activeConfig.active = true;
                    $scope.loading = false;
                },
                function(message) {
                    console.log('Error:',message);
                    $scope.loading = false;
                }
            );

        };

        $scope.save = function(key){

            $scope.loading = true;
            $scope.obj = {};
            $scope.saveMsg = null;

            if(key==='selCompetition'){
                $scope.obj = {value:$scope.selCompetition};

                $scope.competenciaService.onUpdate(
                    $scope.obj,
                    function(object, message) {
                        console.log('Exito:', message);
                        $scope.saveMsg = 'Cambios guardados correctamente';
                    },
                    function(message) {
                        console.log('Error:',message);
                    });

            }else if(key==='selPriority'){

                //To string
                var strProviders = '';
                var separator = '';
                $scope.selPriority.forEach(function(pr){
                        strProviders = strProviders + separator + pr.name;
                        separator = '|';
                });

                $scope.obj = {value:strProviders};
                $scope.prioridadService.onUpdate(
                    $scope.obj,
                    function(object, message) {
                        console.log('Exito:', message);
                        $scope.saveMsg = 'Cambios guardados correctamente';
                    },
                    function(message) {
                        console.log('Error:',message);
                    });
            }
            $scope.loading = false;
        };




    }); //-- Fin Controller


    //------------------------


})();

(function(){

    'use strict';

	angularApp.controller({'DiscountDestinoController':
        function(Util, LomaUtils, DescuentoDestinoService, CRUDService,limitToFilter, $scope) {
          $scope.name = 'Descuento por destino';
          var locations = function(input){

          var loc = LomaUtils.findByName(input).then( function(data) {
              if (data.length === 0) {
                var noResults = {'id': -1,  'label' : 'No hay ciudades'};
                data.push(noResults);
              }
              return limitToFilter(data, 10);
            });

            return loc;
          };

          var select = {'name':'select',
                        'options':'providers',
                        'key':'id',
                        'value':'label',
                        'allOption': true};

          var autocomplete = {'name':'autocomplete',
                              'getInput':locations,
                              'key':'id',
                              'value':'label'};

			    var date = {'name':'date',
                     'format':'yyyy-MM-dd'};

    	  	$scope.columns =  [ {'name':'Destino',
                               'id':'locationName',
                               'type' : autocomplete,
                               'bind' : 'locationId',
                               'editMode' : 'readOnly'
                              },
                              {'name':'Proveedor',
                               'id':'providerName',
                              'type':select,
                              'bind' : 'providerId'
                               },
				                      {'name':'Descuento',
                               'id':'discount',
                               'type':'percentage',
                               'validator': Util.getDiscountValidator()
                              },
                              {'name':'Fecha Desde',
                               'id':'startDate',
                               'type':date},
                              {'name':'Fecha Hasta',
                               'id':'finishDate',
                               'type':date
                             }];

       		  var crudService =new CRUDService(DescuentoDestinoService,'ruleId');
            crudService.onOrderPriority=function(onSuccess, onError){
            this.service.onOrderPriority(function(){
                  onSuccess('','ok');
              },function(){
                  onError('error');
              });
            };

            $scope.crudOperations=crudService;

        }
	});

})();

(function(){

    'use strict';

    angularApp.controller({'DiscountHomeController': function($scope) {                        
            $scope.rules=[
                    { 'id':1,
                     'name':'Descuento por Hotel',
                     'description':'Permite indicar el descuento para un hotel',
                     'viewUrl':'/discount-per-hotel'
                    },
                    { 'id':2,
                     'name':'Descuento por Location',
                     'description':'Permite indicar el descuento para todos los hoteles que se encuentren en un Location',
                     'viewUrl':'/discount-per-location'
                    },
                    { 'id':3,
                     'name':'Descuento por Proveedor',
                     'description':'Permite indicar el descuento para todos los hoteles que provee un proveedor',
                     'viewUrl':'/discount-per-provider'
                    },
                ];
    }});
        angularApp.config(['$routeProvider',
        function($routeProvider) {
            $routeProvider.
                when('/discount-per-hotel', {
                	 controller:'DiscountHotelController',
                	 templateUrl:'views/hoteles-admin-ui/crud-view.html'
                }).
				when('/discount-per-location', {
                    controller:'DiscountDestinoController',
                	templateUrl:'views/hoteles-admin-ui/crud-view.html'
                }).
				when('/discount-per-provider', {
                    controller:'DiscountProveedorController',
                	templateUrl:'views/hoteles-admin-ui/crud-view.html'
                });
  }]);
})();

(function(){

    'use strict';

    angularApp.controller({'DiscountHotelController': function(Util, DiscountHotelService, CRUDService, limitToFilter, HaloService,$scope) { 
            $scope.name = 'Descuento por hotel';
            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};


            var getInput=function(input){
              return HaloService.getHotelList({
               'limit' : 10,
               'offset' : 0,
               'name' : input,
               'completenessFrom' : 0,
               'completenessTo' : 100
              }).$promise.then(function(data){
                console.log('Segunda data', data);
                if (data.length === 0) {
                  var noResults = {'code' : -1, 'hotelName' : 'No hay hoteles'};
                  data.push(noResults);  
                }

                return limitToFilter(data, 10);
              });
            };           


            var autocomplete = {'name':'autocompleteHotel',
                              'getInput':getInput,
                              'key':'code',
                              'value':'hotelName',
                              'firstValue':'code'};

            var select = { 
                          'name':'select',
                          'options':'providers',
                          'key':'id',
                          'value':'label'};

            $scope.columns =  [ {'name':'Nombre',
                                 'id':'hotelName',
                                 'type':autocomplete,
                                 'bind' : 'hotelId',
                                 'editMode' : 'readOnly'
                                },
                                {'name':'Proveedor',
                                 'id':'providerName',
                                'type':select,
                                'bind' : 'providerId'},                              
                                {'name':'Discount',
                                 'id':'discount',
                                 'type':'percentage',
                                 'validator': Util.getDiscountValidator()
                                 },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];
                              
            

              $scope.crudOperations =new CRUDService(DiscountHotelService,'ruleId');  
            }
    });

})();
         

(function(){

    'use strict';

    angularApp.controller({'DiscountProveedorController': function(Util, DiscountProveedorService, CRUDService, $scope) { 
            $scope.name = 'Descuento por Proveedor';
            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};

           var select = {     'name':'select',
                              'options':'providers',
                              'key':'id',
                              'value':'label'};

                              
           $scope.columns =  [ {'name':'Nombre',
                                 'id':'proveedorName',
                                'type':select,
                                'bind' : 'proveedorId'},
                                
                                {'name':'Descuento',
                                 'id':'discount',
                                 'type':'percentage',
                                  'validator': Util.getDiscountValidator()
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];
                                 
        $scope.crudOperations =new CRUDService(DiscountProveedorService,'ruleId');                                   
        }
    });

})();
         

(function(){

    'use strict';

	angularApp.controller({'FiltroDestinoController': 
        function(LomaUtils, FiltroDestinoService, limitToFilter,CRUDService, $scope) {			
          
          $scope.name = 'Filtro por Destino';
          
          var locations = function(input){ 
          var loc = LomaUtils.findByName(input).then( function(data) {
                      if(data.length === 0) {
                          var noResults = {'id': -1,  'label' : 'No hay ciudades'};
                          data.push(noResults);  
                      }
                      return limitToFilter(data, 10);
                    });
            return loc;
          };

          var autocomplete = {'name':'autocomplete',
                              'getInput':locations,
                              'key':'id',
                              'value':'label'};

			    var date = {'name':'date',
                      'format':'yyyy-MM-dd'};

    	  	$scope.columns =  [ {'name':'Destino',
                                 'id':'locationFiltradaName',
                                 'type' : autocomplete,
                                 'bind' : 'locationFiltradaId',
                                 'editMode' : 'readOnly'
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate', 
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}
                             ];

           var crudService =new CRUDService(FiltroDestinoService,'ruleId');
            crudService.onOrderPriority=function(onSuccess, onError){
            this.service.onOrderPriority(function(){
                  onSuccess('','ok');      
              },function(){
                  onError('error');
              });
            };
            
            $scope.crudOperations=crudService;
        }
	});

})();
            
(function(){

    'use strict';

	angularApp.controller({'FiltroHotelController': function(FiltroHotelService, CRUDService,
    limitToFilter, HaloService, $scope) {			

          $scope.name = 'Filtro por hotel';

          var getInput=function(input){
              return HaloService.getHotelList({
               'limit' : 10,
               'offset' : 0,
               'name' : input,
               'completenessFrom' : 0,
               'completenessTo' : 100
              }).$promise.then(function(data){

                if (data.length === 0) {
                  var noResults = {'code' : -1, 'hotelName' : 'No hay hoteles'};
                  data.push(noResults);  
                }

                return limitToFilter(data, 10);
              });
          };

            var autocomplete = {'name':'autocompleteHotel',
                              'getInput':getInput,
                              'key':'code',
                              'value':'hotelName',
                              'firstValue':'code'};
                              
          var date = {'name':'date',
                        'format':'yyyy-MM-dd'};

    	  	$scope.columns =  [   {'name':'Nombre',
                                 'id':'hotelName',
                                 'type':autocomplete,
                                 'bind' : 'hotelId',
                                 'editMode' : 'readOnly'
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                'editMode':'readOnly',
                                'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];


            $scope.crudOperations =new CRUDService(FiltroHotelService,'ruleId');     
            }
	});

})();
            

(function(){

    'use strict';

    angularApp.controller({'FiltroHotelesHomeController': function($scope) {                        
            $scope.rules=[
                    { 'id':1,
                     'name':'Filtro por Destino',
                     'description':'Permite seleccionar un pais y filtrar sus Hoteles',
                     'viewUrl':'/filtro-por-destino'
                    },
                    { 'id':2,
                     'name':'Filtro por Hotel',
                     'description':'Permite seleccionar un hotel y filtrarlo',
                     'viewUrl':'/filtro-por-hotel'
                    }
                ];
    }});
    angularApp.config(['$routeProvider',
        function($routeProvider) {
            $routeProvider.
                when('/filtro-por-destino', {
                    controller:'FiltroDestinoController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
                }).
                when('/filtro-por-hotel', {
                    controller:'FiltroHotelController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
            });
  }]);
})();

(function(){

  'use strict';
  angularApp.controller({'MarginLocationController': function($scope, $route, MarginProviderService, MarginLocationService, LomaUtils) {
    
    $scope.providerTitle = 'Margenes';
    $scope.locationTitle = 'Margenes Destinos';

    var providerId = $route.current.params.providerId;
    var marginLocations = [];

    $scope.providerColumnTitles = ['Proveedor', 'Margen aplicado', 'MU tarifa', 'MU impuesto', 'Prevision de cambio', 'Editar'];
    $scope.locationColumnTitles = ['Destino', 'Código LOMA', 'Margen aplicado', 'MU tarifa', 'MU impuesto', 'Prevision de cambio', 'Ver destino', 'Editar'];

    $scope.marginProvider = {};
    $scope.marginLocations = [];

    var toPercentage = function(stringNumber){
      return parseFloat((stringNumber * 100).toFixed(2));
    };

    var formatMarginProvider = function(response){
        response.marginApplied = toPercentage(response.marginApplied);
        response.rateMarkup = toPercentage(response.rateMarkup);
        response.taxMarkup = toPercentage(response.taxMarkup);
        response.changePrevision = toPercentage(response.changePrevision);

        $scope.marginProvider = angular.copy(response);
    };

    var callbackListError = function(){
      addAlert('danger', 'No pudieron obtenerse los margenes');
    };

    MarginProviderService.get({id: providerId}).$promise.then(formatMarginProvider, callbackListError);

    var compareLocations = function(a, b) {
        if(a.locationName < b.locationName) {
          return -1;
        } else if(a.locationName > b.locationName) {
          return 1;
        }
        return 0;
    };

    var formatMarginLocation = function(response){
      for(var i = 0; i < response.length; i++){
        response[i].marginApplied = toPercentage(response[i].marginApplied);
        response[i].rateMarkup = toPercentage(response[i].rateMarkup);
        response[i].taxMarkup = toPercentage(response[i].taxMarkup);
        response[i].changePrevision = toPercentage(response[i].changePrevision);
        marginLocations.push(response[i]);
      }

      marginLocations = marginLocations.sort(compareLocations);

      if(marginLocations.length > 0) {
        //getTooltip(0);
        getTooltips();
      }
    };

    MarginLocationService.getByProvider({id: providerId}).$promise.then(formatMarginLocation, callbackListError);

    $scope.isProviderEditing = false;

    $scope.editingRowNumber = -1;

    $scope.marginProviderEditingValues = angular.copy($scope.marginProvider);

    $scope.marginLocationEditingValues = {'marginApplied': 0, 'rateMarkup': 50, 'taxMarkup': 50, 'changePrevision': 0};

    $scope.alert = null;

    $scope.enableProviderMarginEdition = function(){
      $scope.isProviderEditing = true;
      $scope.marginProviderEditingValues = angular.copy($scope.marginProvider);
    };

    $scope.cancelProviderMarginEdition = function(){
      $scope.marginProviderEditingValues = angular.copy($scope.marginProvider);
      $scope.isProviderEditing = false;
    };

    $scope.enableLocationMarginEdition = function(index){
      $scope.editingRowNumber = index;
      $scope.marginLocationEditingValues = angular.copy($scope.marginLocations[index]);
    };

    $scope.cancelLocationMarginEdition = function(){
      $scope.marginLocationEditingValues = angular.copy($scope.marginLocations[$scope.editingRowNumber]);
      $scope.editingRowNumber = -1;
    };

    $scope.calculeTaxMarkupProvider = function(){
      if(!isNaN($scope.marginProviderEditingValues.rateMarkup)){
        $scope.marginProviderEditingValues.taxMarkup = parseFloat((100 - $scope.marginProviderEditingValues.rateMarkup).toFixed(2));
      }
    };

    $scope.calculeRateMarkupProvider = function(){
      if(!isNaN($scope.marginProviderEditingValues.taxMarkup)){
        $scope.marginProviderEditingValues.rateMarkup = parseFloat((100 - $scope.marginProviderEditingValues.taxMarkup).toFixed(2));
      }
    };

    $scope.calculeTaxMarkupLocation = function(){
      if(!isNaN($scope.marginLocationEditingValues.rateMarkup)){
        $scope.marginLocationEditingValues.taxMarkup = parseFloat((100 - $scope.marginLocationEditingValues.rateMarkup).toFixed(2));
      }
    };

    $scope.calculeRateMarkupLocation = function(){
      if(!isNaN($scope.marginLocationEditingValues.taxMarkup)){
        $scope.marginLocationEditingValues.rateMarkup = parseFloat((100 - $scope.marginLocationEditingValues.taxMarkup).toFixed(2));
      }
    };

    $scope.updateMarginProvider = function(){
      var marginToUpdate = angular.copy($scope.marginProviderEditingValues);

      marginToUpdate.marginApplied = (marginToUpdate.marginApplied / 100).toFixed(4).toString();
      marginToUpdate.rateMarkup = (marginToUpdate.rateMarkup / 100).toFixed(4).toString();
      marginToUpdate.taxMarkup = (marginToUpdate.taxMarkup / 100).toFixed(4).toString();
      marginToUpdate.changePrevision = (marginToUpdate.changePrevision / 100).toFixed(4).toString();

      MarginProviderService.update(marginToUpdate).$promise.then(callbackUpdateMarginProviderOK, callbackUpdateMarginProviderError);
    };

/*
    var getTooltip = function(index) {
      var margin = marginLocations[index];
      LomaUtils.getParentsById(margin.locationId).then(function(response) {
        if(response.length > 0) {
          margin.locationPath = response[0].label;
          margin.locationName = response[0].locationName;
        }
        
        $scope.marginLocations.push(margin);
        if(index + 1 < marginLocations.length) {
          getTooltip(index + 1);
        }
      }, function() {
        if(index + 1 < marginLocations.length) {
          getTooltip(index + 1);
        }
      });
    };
*/

    var getTooltips = function() {
      //var promises = [];
      var count = 0;
      marginLocations.forEach(function(margin, index) {
        LomaUtils.getParentsById(margin.locationId).then(function(response) {
          if(response.length > 0) {
            margin.locationPath = response[0].label;
            margin.locationName = response[0].locationName;
          }
          marginLocations[index] = margin;

          count++;
          if(count === marginLocations.length) {
            $scope.marginLocations = marginLocations.sort(compareLocations);
          }
        });
      });
    };

    var callbackUpdateMarginProviderOK = function(response){
      addAlert('success', 'Margen de ' + $scope.marginProvider.providerName + ' actualizado exitosamente');

      response.$promise.$$state.value.marginApplied = toPercentage(response.$promise.$$state.value.marginApplied);
      response.$promise.$$state.value.rateMarkup = toPercentage(response.$promise.$$state.value.rateMarkup);
      response.$promise.$$state.value.taxMarkup = toPercentage(response.$promise.$$state.value.taxMarkup);
      response.$promise.$$state.value.changePrevision = toPercentage(response.$promise.$$state.value.changePrevision);

      $scope.marginProvider = response.$promise.$$state.value;
      $scope.isProviderEditing = false;
    };

    var callbackUpdateMarginProviderError = function(){
      addAlert('danger', 'El margen de ' + $scope.marginProvider.providerName + ' no se pudo actualizar');
    };

    $scope.updateMarginLocation = function(){
      var marginToUpdate = angular.copy($scope.marginLocationEditingValues);

      delete marginToUpdate.locationPath;
      marginToUpdate.marginApplied = (marginToUpdate.marginApplied / 100).toFixed(4).toString();
      marginToUpdate.rateMarkup = (marginToUpdate.rateMarkup / 100).toFixed(4).toString();
      marginToUpdate.taxMarkup = (marginToUpdate.taxMarkup / 100).toFixed(4).toString();
      marginToUpdate.changePrevision = (marginToUpdate.changePrevision / 100).toFixed(4).toString();

      MarginLocationService.update(marginToUpdate).$promise.then(callbackUpdateMarginLocationOK, callbackUpdateMarginLocationError);
    };

    var callbackUpdateMarginLocationOK = function(response){
      addAlert('success', 'Margen de ' + $scope.marginLocations[$scope.editingRowNumber].locationName + ' actualizado exitosamente');

      $scope.marginLocations[$scope.editingRowNumber].marginApplied = toPercentage(response.$promise.$$state.value.marginApplied);
      $scope.marginLocations[$scope.editingRowNumber].rateMarkup = toPercentage(response.$promise.$$state.value.rateMarkup);
      $scope.marginLocations[$scope.editingRowNumber].taxMarkup = toPercentage(response.$promise.$$state.value.taxMarkup);
      $scope.marginLocations[$scope.editingRowNumber].changePrevision = toPercentage(response.$promise.$$state.value.changePrevision);      

      $scope.editingRowNumber = -1;
    };

    var callbackUpdateMarginLocationError = function(){
      addAlert('danger', 'El margen de ' + $scope.marginLocations[$scope.editingRowNumber].locationName + ' no se pudo actualizar');
    };

    var addAlert = function(type, msg){
      $scope.alert = {'type': type, 'msg': msg};
    };

    $scope.closeAlert = function() {
      $scope.alert = null;
    };

  }});

  angularApp.config(['$routeProvider', function($routeProvider) {      
    $routeProvider.
    when('/margenes-destino/:providerId', {
      controller:'MarginLocationController',
      templateUrl:'views/hoteles-admin-ui/margin-location.html'
    });
  }]);  

})();
(function(){

  'use strict';
  angularApp.controller({'MarginProviderController': function($scope, MarginProviderService) {
    
    $scope.name = 'Margenes Proveedores';

    $scope.columnTitles = ['Proveedor', 'Margen aplicado', 'MU tarifa', 'MU impuesto',
                          'Prevision de cambio', 'Ver proveedor', 'Activo', 'Editar'];

    $scope.marginProviders = [];

    var toPercentage = function(stringNumber){
      return parseFloat((stringNumber * 100).toFixed(2));
    };

    var formatMarginProvider = function(response){
      for(var i = 0; i < response.length; i++){
        response[i].marginApplied = toPercentage(response[i].marginApplied);
        response[i].rateMarkup = toPercentage(response[i].rateMarkup);
        response[i].taxMarkup = toPercentage(response[i].taxMarkup);
        response[i].changePrevision = toPercentage(response[i].changePrevision);

        $scope.marginProviders.push(response[i]);
      }
    };

    var callbackListError = function(){
      addAlert('danger', 'No pudieron obtenerse los margenes');
    };

    MarginProviderService.listAll().$promise.then(formatMarginProvider, callbackListError);

    $scope.editingRowNumber = -1;

    $scope.editValues = {'marginApplied': 0, 'rateMarkup': 50, 'taxMarkup': 50, 'changePrevision': 0};

    $scope.alert = null;

    $scope.activateEditMode = function(index){
      $scope.editingRowNumber = index;
      $scope.editValues = angular.copy($scope.marginProviders[index]);
    };

    $scope.cancelEdition = function(){
      $scope.editValues = angular.copy($scope.marginProviders[$scope.editingRowNumber]);
      $scope.editingRowNumber = -1;
    };

    $scope.calculeTaxMarkup = function(){
      if(!isNaN($scope.editValues.rateMarkup)){
        $scope.editValues.taxMarkup = 100 - $scope.editValues.rateMarkup;
      }
    };

    $scope.calculeRateMarkup = function(){
      if(!isNaN($scope.editValues.taxMarkup)){
        $scope.editValues.rateMarkup = 100 - $scope.editValues.taxMarkup;
      }
    };

    $scope.updateMargin = function(){
      var marginToUpdate = angular.copy($scope.editValues);

      marginToUpdate.marginApplied = (marginToUpdate.marginApplied / 100).toFixed(4).toString();
      marginToUpdate.rateMarkup = (marginToUpdate.rateMarkup / 100).toFixed(4).toString();
      marginToUpdate.taxMarkup = (marginToUpdate.taxMarkup / 100).toFixed(4).toString();
      marginToUpdate.changePrevision = (marginToUpdate.changePrevision / 100).toFixed(4).toString();

      MarginProviderService.update(marginToUpdate).$promise.then(callbackUpdateOK, callbackUpdateError);
    };

    var callbackUpdateOK = function(response){
      addAlert('success', 'Margen de ' + $scope.marginProviders[$scope.editingRowNumber].providerName + ' actualizado exitosamente');

      response.$promise.$$state.value.marginApplied = toPercentage(response.$promise.$$state.value.marginApplied);
      response.$promise.$$state.value.rateMarkup = toPercentage(response.$promise.$$state.value.rateMarkup);
      response.$promise.$$state.value.taxMarkup = toPercentage(response.$promise.$$state.value.taxMarkup);
      response.$promise.$$state.value.changePrevision = toPercentage(response.$promise.$$state.value.changePrevision);

      $scope.marginProviders[$scope.editingRowNumber] = response.$promise.$$state.value;
      //$scope.editValues = angular.copy($scope.marginProviders[$scope.editingRowNumber]);
      $scope.editingRowNumber = -1;
    };

    var callbackUpdateError = function(){
      addAlert('danger', 'El margen de ' + $scope.marginProviders[$scope.editingRowNumber].providerName + ' no se pudo actualizar');
    };

    $scope.enableDisableMargin = function(index){
      if ($scope.marginProviders[index].active === 'true'){
        MarginProviderService.delete({id: $scope.marginProviders[index].ruleId}).$promise.then(callbackDeleteOK, callbackDeleteError);
      }
      else{
        MarginProviderService.activate({id: $scope.marginProviders[index].ruleId}).$promise.then(callbackActivateOK, callbackActivateError);
      }
    };

    var callbackActivateOK = function(){
      addAlert('success', 'Margen de ' + $scope.marginProviders[$scope.editingRowNumber].providerName + ' activado exitosamente');
      $scope.marginProviders[$scope.editingRowNumber].active = 'true';
      $scope.editingRowNumber = -1;
    };

    var callbackActivateError = function(){
      addAlert('danger', 'El margen de ' + $scope.marginProviders[$scope.editingRowNumber].providerName + ' no se pudo activar');
    };

    var callbackDeleteOK = function(){
      addAlert('success', 'Margen de ' + $scope.marginProviders[$scope.editingRowNumber].providerName + ' desactivado exitosamente');
      $scope.marginProviders[$scope.editingRowNumber].active = 'false';
      $scope.editingRowNumber = -1;
    };

    var callbackDeleteError = function(){
      addAlert('danger', 'El margen de ' + $scope.marginProviders[$scope.editingRowNumber].providerName + ' no se pudo desactivar');
    };

    var addAlert = function(type, msg){
      $scope.alert = {'type': type, 'msg': msg};
    };

    $scope.closeAlert = function() {
      $scope.alert = null;
    };

  }});

  angularApp.config(['$routeProvider', function($routeProvider) {      
    $routeProvider.
    when('/margenes-proveedor', {
      controller:'MarginProviderController',
      templateUrl:'views/hoteles-admin-ui/margin-provider.html'
    });
  }]);  

})();
(function(){

  'use strict';
  angularApp.controller({'MarginsLocationController': function($scope, $route, MarginProviderService, MarginLocationService) {
    
    var locationId = $route.current.params.locationId;
    
    $scope.tableTitle = 'Margenes';
    $scope.columnTitles = ['Proveedores', 'Margen de Proveedor', 'Margen aplicado', 'MU Tarifa', 'MU Imp.', 'Previsión de Cambio', 'Editar'];
    $scope.locationName = '';
    $scope.notApply = 'N/A';
    $scope.offProvider = 'Off';
    $scope.editing = -1;
    $scope.alert = null;

    $scope.marginProviders = [];
    $scope.marginsLocation = [];
    $scope.editingMarginsLocation = [];

    $scope.requiredError = 'Este campo es requerido';
    $scope.marginRangeError = 'El valor de Margen Aplicado deberá ser entre 0% y 100%.';
    $scope.changePrevisionRangeError = 'El valor de Previsión de cambio deberá ser mayor a 0%.';
    $scope.rateMarkupRangeError = 'El valor de % MU Tarifa deberá ser entre 0% y 100%.';
    $scope.taxMarkupRangeError = 'El valor de % MU Impuestos deberá ser entre 0% y 100%.';
    $scope.markupSumError = 'La suma de % MU Tarifa y % MU Impuestos deberá ser 100%.';
    $scope.sumError = false;

    var marginProvidersCallback = function(response) {
      for (var i = 0; i < response.length; i++) {
        var marginProvider = response[i];
        marginProvider.marginApplied = toPercentage(marginProvider.marginApplied);
        marginProvider.active = marginProvider.active === 'true';
        $scope.marginProviders.push(marginProvider);
      }

      // Una vez que tengo los proveedores, busco los margenes para esta location
      MarginLocationService.getByLocation({id: locationId}).$promise.then(marginsLocationCallback, marginsLocationErrorCallback);
    };

    var marginProvidersErrorCallback = function() {
      createAlert('danger', 'No se pudo obtener los márgenes de proveedor');
    };

    // Obtener los providers
    MarginProviderService.listAll().$promise.then(marginProvidersCallback, marginProvidersErrorCallback);

    var marginsLocationCallback = function(response) {
      $scope.marginsLocation = new Array($scope.marginProviders.length);

      if(response.length > 0) {
        $scope.locationName = response[0].locationName;
        $scope.columnTitles[2] = $scope.columnTitles[2] + ' "' + $scope.locationName + '"';
      }

      for(var i = 0; i < response.length; i++) {
        var marginLocation = response[i];
        marginLocation.marginApplied = toPercentage(marginLocation.marginApplied);
        marginLocation.rateMarkup = toPercentage(marginLocation.rateMarkup);
        marginLocation.taxMarkup = toPercentage(marginLocation.taxMarkup);
        marginLocation.changePrevision = toPercentage(marginLocation.changePrevision);

        for(var j = 0; j < $scope.marginProviders.length; j++) {
          if(marginLocation.providerId === $scope.marginProviders[j].providerId) {
            $scope.marginsLocation[j] = marginLocation;
            break;
          }
        }
      }

      $scope.editingMarginsLocation = angular.copy($scope.marginsLocation);
    };

    var marginsLocationErrorCallback = function() {
      createAlert('danger', 'No se pudo obtener los márgenes de destino');
    };

    $scope.enableEdition = function(index) {
      $scope.sumError = false;
      $scope.editing = index;
    };

    $scope.cancelEdition = function() {
      $scope.editingMarginsLocation[$scope.editing] = angular.copy($scope.marginsLocation[$scope.editing]);
      $scope.editing = -1;
    };

    $scope.updateMarginsLocation = function() {
      $scope.alert = null;

      var toUpdate = angular.copy($scope.editingMarginsLocation[$scope.editing]);
      toUpdate.marginApplied = fromPercentage(toUpdate.marginApplied);
      toUpdate.rateMarkup = fromPercentage(toUpdate.rateMarkup);
      toUpdate.taxMarkup = fromPercentage(toUpdate.taxMarkup);
      toUpdate.changePrevision = fromPercentage(toUpdate.changePrevision);

      MarginLocationService.update(toUpdate).$promise.then(callbackUpdatedOK, callbackUpdatedBad);
    };

    var callbackUpdatedOK = function(marginLocation) {
      marginLocation.marginApplied = toPercentage(marginLocation.marginApplied);
      marginLocation.rateMarkup = toPercentage(marginLocation.rateMarkup);
      marginLocation.taxMarkup = toPercentage(marginLocation.taxMarkup);
      marginLocation.changePrevision = toPercentage(marginLocation.changePrevision);

      $scope.marginsLocation[$scope.editing] = marginLocation;
      $scope.updateMarginsLocation[$scope.editing] = marginLocation;

      createAlert('success', 'Margen de ' + marginLocation.providerName + ' actualizado exitosamente');
      $scope.editing = -1;
    };

    var callbackUpdatedBad = function() {
      $scope.editingMarginsLocation[$scope.editing] = $scope.marginsLocation[$scope.editing];
      createAlert('danger', 'El margen de ' + $scope.editingMarginsLocation[$scope.editing].providerName + ' no se pudo actualizar');
      $scope.editing = -1;
    };

    var toPercentage = function(stringNumber){
      return parseFloat((stringNumber * 100).toFixed(2));
    };

    var fromPercentage = function(stringPercentage) {
      return parseFloat((stringPercentage / 100).toFixed(4));
    };

    var createAlert = function(type, msg){
      $scope.alert = {'type': type, 'msg': msg};
    };

    $scope.closeAlert = function() {
      $scope.alert = null;
    };

    $scope.isEditing = function() {
      return $scope.editing > -1;
    };

    $scope.isEditingRow = function(index) {
      return $scope.editing === index;
    };

    $scope.calculateRateMarkup = function() {
      var taxMarkup = $scope.editingMarginsLocation[$scope.editing].taxMarkup;
      if(!isNaN(taxMarkup)){
        $scope.editingMarginsLocation[$scope.editing].rateMarkup = parseFloat((100 - taxMarkup).toFixed(2));
      }
    };

    $scope.calculateTaxMarkup = function() {
      var rateMarkup = $scope.editingMarginsLocation[$scope.editing].rateMarkup;
      if(!isNaN(rateMarkup)){
        $scope.editingMarginsLocation[$scope.editing].taxMarkup = parseFloat((100 - rateMarkup).toFixed(2));
      }
    };
  }});

  angularApp.config(['$routeProvider', function($routeProvider) {      
    $routeProvider.
    when('/margen-destino/:locationId', {
      controller:'MarginsLocationController',
      templateUrl:'views/hoteles-admin-ui/margins-location.html'
    });
  }]);  

})();
(function(){

    'use strict';

    angularApp.controller({'MarkupDefaultController': function(Util, MarkupDefaultService, $scope) {      
   $scope.name = 'Markup por default';
            $scope.columns =  [ {'name':'Markup',
                                 'id':'markup',
                                 'validator': Util.getMarkUpValidator()
                             }];

            $scope.crudOperations = {
                    onUpdate: function(object, onSucces, onError){
                        MarkupDefaultService.update(object,function(){
                            onSucces(object,'ok');         
                        },
                        function(){
                            onError('error');
                        });                      
                    },
                    onList:function(onSucces, onError){
                        MarkupDefaultService.list({}).$promise.then(function(data){
                            onSucces(data,'ok'); 
                        }, function(){
                            onError('error');
                        });
                    },
                };
            }
    });

})();
(function(){

    'use strict';

    angularApp.controller({'MarkupHomeController': function($scope) {                        
            $scope.rules=[
                    { 'id':1,
                     'name':'Markup por Destino (Locación)',
                     'description':'Permite definir el markup a utilizar para todos los hoteles de un destino(el cual puede ser una ciudad o un  país)',
                     'viewUrl':'/markup-por-location'
                    },
                    { 'id':2,
                     'name':'Markup por Hotel',
                     'description':'Permite definir el markup a utilizar para un hotel',
                     'viewUrl':'/markup-por-hotel'
                    },
                    { 'id':3,
                     'name':'Markup por Default',
                     'description':'XXXXXXXXXXXXX',
                     'viewUrl':'/markup-por-default'
                    },
					{ 'id':4,
				             'name':'Markup por Proveedor',
				             'description':'Permite definir el markup a aplicar sobre todos los hoteles que prevee un proveedor',
				             'viewUrl':'/markup-por-proveedor'
				            },
					{ 'id':5,
				             'name':'Markup sobre impuestos',
				             'description':'Permite definir el markup a aplicar sobre los impuestos',
				             'viewUrl':'/markup-sobre-impuesto'
				            },
				        ];
    }});
        angularApp.config(['$routeProvider',
        function($routeProvider) {
            $routeProvider.
                when('/markup-por-location', {
                    controller:'MarkupLocationController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
                }).
                when('/markup-por-hotel', {
                    controller:'MarkupHotelController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
                }).
                when('/markup-por-default', {
                    controller:'MarkupDefaultController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
            	}).
                when('/markup-por-proveedor', {
                    controller:'MarkupProveedorController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
            	}).
                when('/markup-sobre-impuesto', {
                    controller:'MarkupOnTaxesController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
            	});
  }]);
})();

(function(){

    'use strict';

    angularApp.controller({'MarkupHotelController': function(Util, MarkupHotelService,CRUDService,limitToFilter, HaloService, $scope) { 
            $scope.name = 'Markup por hotel';
            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};
                       

           var getInput = function(input){
              return HaloService.getHotelList({
               'limit' : 10,
               'offset' : 0,
               'name' : input,
               'completenessFrom' : 0,
               'completenessTo' : 100
              }).$promise.then(function(data){

                if (data.length === 0) {
                  var noResults = {'code' : -1, 'hotelName' : 'No hay hoteles'};
                  data.push(noResults);  
                }

                return limitToFilter(data, 10);
              });
            };  
         


           var select = { 
                          'name':'select',
                          'options':'providers',
                          'key':'id',
                          'value':'label'};

            var autocomplete = {'name':'autocompleteHotel',
                              'getInput':getInput,
                              'key':'code',
                              'value':'hotelName',
                              'firstValue':'code'};

            $scope.columns =  [ {'name':'Nombre',
                                 'id':'hotelName',
                                 'type':autocomplete,
                                 'bind' : 'hotelId',
                                 'editMode' : 'readOnly'
                                },
                                {'name':'Proveedor',
                                 'id':'providerName',
                                'type':select,
                                'bind' : 'providerId'},
                                {'name':'Markup',
                                 'id':'markup',
                                 'type':'percentage',
                                 'validator': Util.getMarkUpValidator()
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];
                  $scope.crudOperations =new CRUDService(MarkupHotelService,'ruleId');                           
         
            }
    });

})();
         

(function(){

    'use strict';

    angularApp.controller({'MarkupLocationController': function(Util, MarkupLocationService,CRUDService,LomaUtils,limitToFilter, $scope) {
            $scope.name = 'Markup por Destino';
            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};

            var locations = function(input){

            var loc = LomaUtils.findByName(input).then( function(data) {
              if (data.length === 0) {
                var noResults = {'id': -1,  'label' : 'No hay ciudades'};
                data.push(noResults);
              }
                 return limitToFilter(data, 10);
             });
               return loc;
            };

          var select = {'name':'select',
                        'options':'providers',
                        'key':'id',
                        'value':'label',
                        'allOption': true};

          var autocomplete = {'name':'autocomplete',
                              'getInput':locations,
                              'key':'id',
                              'value':'label'};

            $scope.columns =  [{'name':'Destino',
                               'id':'locationName',
                               'type' : autocomplete,
                               'bind' : 'locationId',
                               'editMode' : 'readOnly'
                               },
                               {'name':'Proveedor',
                                'id':'providerName',
                               'type':select,
                               'bind' : 'providerId'
                                },
                                {'name':'Markup',
                                 'id':'markup',
                                 'type':'percentage',
                                 'validator': Util.getMarkUpValidator()
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date},
                             ];

            var crudService =new CRUDService(MarkupLocationService,'ruleId');
            crudService.onOrderPriority=function(onSuccess, onError){
            this.service.onOrderPriority(function(){
                  onSuccess('','ok');
              },function(){
                  onError('error');
              });
            };

            $scope.crudOperations=crudService;
            }
    });

})();

(function(){

    'use strict';

    angularApp.controller({'MarkupProveedorController': function(Util,MarkupProveedorService,CRUDService, $scope) { 
           $scope.name = 'Markup por Proveedor';
          
           var date = {'name':'date',
                        'format':'yyyy-MM-dd'};


              var select = {       'name':'select',
                              'options':'providers',
                              'key':'id',
                              'value':'label'};
           
           $scope.columns =  [ {'name':'Nombre',
                                 'id':'proveedorName',
                                'type':select,
                                'bind' : 'proveedorId'},
                                {'name':'Markup',
                                 'id':'markup',
                                 'type':'percentage',
                                 'validator': Util.getMarkUpValidator()},
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];

            $scope.crudOperations =new CRUDService(MarkupProveedorService,'ruleId');                    
       
            }
    });

})();
         
(function(){

    'use strict';

    angularApp.controller({'MarkupOnTaxesDefaultController': function(Util, MarkupOnTaxesDefaultService, $scope) {      
        $scope.name = 'Markup a impuestos por Default';
           $scope.columns =  [  {'name':'Markup',
                                 'id':'markup',
                                 'validator': Util.getMarkUpValidator()}
                                ];
            $scope.crudOperations = {
                    onUpdate: function(object, onSucces, onError){
                        MarkupOnTaxesDefaultService.update(object,function(){
                            onSucces(object,'ok');         
                        },
                        function(){
                            onError('error');
                        });                      
                    },
                    onList:function(onSucces, onError){
                        MarkupOnTaxesDefaultService.list({}).$promise.then(function(data){
                            onSucces(data,'ok'); 
                        }, function(){
                            onError('error');
                        });
                    },
                };
            }
    });

})();
(function(){

    'use strict';

    angularApp.controller({'MarkupOnTaxesForHotelController': function(Util, MarkupOnTaxesForHotelService,CRUDService,limitToFilter, HaloService, $scope) { 
            $scope.name = 'Markup a impuestos por hotel';
            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};
                       

           var getInput = function(input){
              return HaloService.getHotelList({
               'limit' : 10,
               'offset' : 0,
               'name' : input,
               'completenessFrom' : 0,
               'completenessTo' : 100
              }).$promise.then(function(data){

                if (data.length === 0) {
                  var noResults = {'code' : -1, 'hotelName' : 'No hay hoteles'};
                  data.push(noResults);  
                }

                return limitToFilter(data, 10);
              });
            };  
         


           var select = { 
                          'name':'select',
                          'options':'providers',
                          'key':'id',
                          'value':'label'};

            var autocomplete = {'name':'autocompleteHotel',
                              'getInput':getInput,
                              'key':'code',
                              'value':'hotelName',
                              'firstValue':'code'};

            $scope.columns =  [ {'name':'Nombre',
                                 'id':'hotelName',
                                 'type':autocomplete,
                                 'bind' : 'hotelId',
                                 'editMode' : 'readOnly'
                                },
                                {'name':'Proveedor',
                                 'id':'providerName',
                                'type':select,
                                'bind' : 'providerId'},
                                {'name':'Markup',
                                 'id':'markup',
                                 'type':'percentage',
                                 'validator': Util.getMarkUpValidator()
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];
                  $scope.crudOperations =new CRUDService(MarkupOnTaxesForHotelService,'ruleId');                       
         
            }
    });

})();
         

(function(){

    'use strict';

    angularApp.controller({'MarkupOnTaxesForLocationController': function(Util,MarkupOnTaxesForLocationService,CRUDService,LomaUtils,limitToFilter, $scope) {      
           $scope.name = 'Markup a impuestos por Destino';
            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};
         var locations = function(input){

            var loc = LomaUtils.findByName(input).then( function(data) {
              if (data.length === 0) {
                var noResults = {'id': -1,  'label' : 'No hay ciudades'};
                data.push(noResults);
              }
                 return limitToFilter(data, 10);
             });
               return loc;
            };

          var select = {'name':'select',
                        'options':'providers',
                        'key':'id',
                        'value':'label',
                        'allOption': true};

          var autocomplete = {'name':'autocomplete',
                              'getInput':locations,
                              'key':'id',
                              'value':'label'};

            $scope.columns =  [{'name':'Destino',
                               'id':'locationName',
                               'type' : autocomplete,
                               'bind' : 'locationId',
                               'editMode' : 'readOnly'
                               },
                               {'name':'Proveedor',
                                'id':'providerName',
                               'type':select,
                               'bind' : 'providerId'
                                },
                                {'name':'Markup',
                                 'id':'markup',
                                 'type':'percentage',
                                 'validator': Util.getMarkUpValidator()
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date},
                             ];   

            var crudService =new CRUDService(MarkupOnTaxesForLocationService,'ruleId');
            crudService.onOrderPriority=function(onSuccess, onError){
            this.service.onOrderPriority(function(){
                  onSuccess('','ok');
              },function(){
                  onError('error');
              });
            };

            $scope.crudOperations=crudService;               
            }
    });
})();




(function(){

    'use strict';

    angularApp.controller({'MarkupOnTaxesForProviderController': function(Util,MarkupOnTaxesForProviderService,CRUDService, $scope) {      
           $scope.name = 'Markup a impuestos por Proveedor';
            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};
         var select = {       'name':'select',
                              'options':'providers',
                              'key':'id',
                              'value':'label'};
                              
           $scope.columns =  [ {'name':'Nombre',
                                 'id':'proveedorName',
                                'type':select,
                                'bind' : 'proveedorId'},
                               {'name':'Markup',
                                 'id':'markup',
                                 'type':'percentage',
                                 'validator': Util.getMarkUpValidator()},
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}];

            $scope.crudOperations =new CRUDService(MarkupOnTaxesForProviderService,'ruleId');                    
            }
    });
})();




(function(){

    'use strict';

    angularApp.controller({'CreditCardCommonsAddController': function($scope,DidadiConstant,CreditCardCommonsService,CRUDService,$location, UICtrl, config){

        $scope.crudOperations = new CRUDService(CreditCardCommonsService);
        $scope.object = {};
        $scope.objects = [];
        $scope.errorCuotas = [];
        $scope.gcaConfig = config['hoteles-admin-ui']['gca-percent'] * 100;
        $scope.modo = 'new';

        $scope.name = 'Agregar Promo Financiación';

        //Servicios Didadi
        var bancos = DidadiConstant.bancos();
        var tarjetas = DidadiConstant.tarjetas();

        $scope.seltarjetas = [];
        $scope.bancos = angular.copy(bancos);
        $scope.tarjetas = angular.copy(tarjetas);

        $scope.cuotas =
            [
                {
                    select: true, cuotas: 1, intereses: 0, gca: 0, isDelete: false, disabled: true, selectDisabled: true
                },
                {
                    select: false, cuotas: 3, intereses: 0, gca: 0, isDelete: false, disabled: true, selectDisabled: false
                },
                {
                    select: false, cuotas: 6, intereses: 0, gca: 0, isDelete: false, disabled: true, selectDisabled: false
                },
                {
                    select: false, cuotas: 9, intereses: 0, gca: 0, isDelete: false, disabled: true, selectDisabled: false
                },
                {
                    select: false, cuotas: 12, intereses: 0, gca: 0, isDelete: false, disabled: true, selectDisabled: false
                }
            ];


        $scope.todosTarjetas = function(val){
            $scope.seltarjetas = [];
            $scope.seltarjetas = val ? angular.copy(tarjetas): [];
        };

        $scope.todosBancos = function(val){
            $scope.selbancos = [];
            $scope.selbancos = val ? angular.copy(bancos): [];
        };

        $scope.agregar = function() {
            var sum;
            if($scope.cuotas){
                sum = $scope.cuotas[$scope.cuotas.length - 1].cuotas < 10 ? 3 : 6;
            }
            else{
                sum = 1;
            }

            var nuevo = {};
            nuevo.select = false;
            nuevo.cuotas = $scope.cuotas[$scope.cuotas.length - 1].cuotas + sum;
            nuevo.intereses = 0;
            nuevo.gca = 0;
            nuevo.isDelete = true;
            nuevo.disabled = false;
            nuevo.selectDisabled = false;
            $scope.cuotas.push(nuevo);
        };

        $scope.removeRow = function(item) {
            $scope.cuotas.splice(item, 1);
        };

        $scope.errFilter = function(item){
            var flag = false;
            $scope.errorCuotas.forEach(function(cuotas){
                if(cuotas.id === item.id){
                    flag = true;
                }
            });

            return flag;
        };

        $scope.validDate = false;

        $scope.validarFechas = function(fechaDesde, fechaHasta){
            if(fechaDesde > fechaHasta) {
                $scope.validDate = true;
                return true;
            } else {
                $scope.validDate = false;
                return false;
            }
        };

        $scope.validarFechasButton = function(){
            var flag = false;
            if($scope.modo !== 'new') {
                $scope.objects.forEach(function (obj) {
                    if (obj.startDate > obj.finishDate) {
                        flag = true;
                    }
                });
            }
            return flag;
        };

        $scope.reloadPage = function(){window.location.reload();};
        $scope.back = function(){$location.path('/commons-credit-cards');};

        $scope.guardar = function(){

            UICtrl.showLoading();
            if($scope.errorCuotas.length===0) {
                //Generar el producto cartesiano de Bancos - Tarjetas - Cuotas
                var i = 0;
                $scope.selbancos.forEach(function (bancoValue) {

                    $scope.seltarjetas.forEach(function (tarjetaValue) {

                        $scope.cuotas.forEach(function (cuotaValue) {

                            if (cuotaValue.select === true) {

                                $scope.object.id = i++;
                                $scope.object.bankId = bancoValue.id;
                                $scope.object.bankName = bancoValue.name;
                                $scope.object.creditCardId = tarjetaValue.id;
                                $scope.object.creditCardName = tarjetaValue.name;
                                $scope.object.installmentCount = cuotaValue.cuotas;
                                $scope.object.finishDate = moment($scope.fechaHasta).format('YYYY-MM-DD HH:mm');
                                $scope.object.gcaPercent = cuotaValue.gca / 100;
                                $scope.object.interest = cuotaValue.intereses / 100;
                                $scope.object.startDate = moment($scope.fechaDesde).format('YYYY-MM-DD HH:mm');

                                $scope.objects.push($scope.object);
                                $scope.object = {};

                            }
                        });
                    });
                });
            }else{ //Entro por aca cuando reenvio los errores corregidos
                $scope.errorCuotas.forEach(function(err){
                    $scope.objects[err.id].startDate = moment($scope.objects[err.id].startDate).format('YYYY-MM-DD HH:mm');
                    $scope.objects[err.id].finishDate = moment($scope.objects[err.id].finishDate).format('YYYY-MM-DD HH:mm');
                });
            }

            //Enviar al servicio Custom
            $scope.crudOperations.onCreateCustom(
                $scope.objects,
                function(object, message) {
                    $scope.objects = [];
                    $scope.errorCuotas = [];
                    console.log('Exito:', message);
                    $scope.modo = 'ok';
                    UICtrl.hideLoading();
                    $scope.back();
                },
                function(rows) {
                    if(rows.length>=1){
                        $scope.errorCuotas = rows;
                    }
                    console.log('Error:',$scope.errorCuotas.length);
                    $scope.modo = 'error';
                    UICtrl.hideLoading();
            });

        };
    }
    });


    /******************** DatePicker *******************/
    angularApp.directive('tarjetasDatetimepicker', function() {
        var format = 'YYYY-MM-DD HH:mm';

        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, element, attributes, ctrl) {
                element.datetimepicker({
                    format: format,
                    sideBySide: true

                });
                var picker = element.data('DateTimePicker');

                ctrl.$formatters.push(function(value) {
                    var aux = value.match(/^(\d+)\/(\d+)\/(\d+) (\d+)\:(\d+)$/);
                    var date = moment(new Date(aux[3], aux[2] - 1, aux[1], aux[4], aux[5], '00'));
                    if (date.isValid()) {
                        return date.format(format);
                    }
                    return '';
                });

                element.on('dp.change', function() {
                    scope.$apply(function() {
                        var date = picker.viewDate();
                        ctrl.$setViewValue(date.valueOf());
                    });
                });
            }
        };
    });

})();

(function(){

    'use strict';

   angularApp.controller({'CreditCardCommonsController': function(Util, CreditCardCommonsService,CRUDService,limitToFilter,
        HaloService,$scope) {
            $scope.name = 'ON/OFF de TC, Bancos y Cuotas en Hoteles';

            var selectBank =  {'name':'select',
                              'options':'bancos',
                              'key':'id',
                              'value':'name'
                        };


           var selectCreditCard = {'name':'select',
                              'options':'tarjetas',
                              'key':'id',
                              'value':'name'
                        };

            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};

            $scope.columns =  [ {'name':'Nombre del banco',
                                 'id':'bankName',
                                'type':selectBank,
                                'bind' : 'bankId',
                                'editMode' : 'readOnly',
                              },
                                {'name':'Nombre de la tarjeta de crédito',
                                 'id':'creditCardName',
                                'type':selectCreditCard,
                                'bind' : 'creditCardId',
                                'editMode' : 'readOnly',
                              },
                                {'name':'Cantidad de cuotas',
                                 'id':'installmentCount',
                                },
                                {'name':'Intereses',
                                 'id':'interest',
                                 'type':'percentage',
                                 'validator': Util.getInterestValidator()
                                },
                                {'name':'% valor a cobrar de GCA',
                                 'id':'gcaPercent',
                                 'type':'percentage',
                                 'validator': Util.getGCAValidator()
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}
                                ];
            $scope.crudOperations =new CRUDService(CreditCardCommonsService,'ruleId');
            }
    });

})();

(function(){

    'use strict';

    angularApp.controller({'CreditCardHotelsController': function(Util, CreditCardHotelsService,CRUDService,limitToFilter, HaloService, $scope) {
            $scope.name = 'ON/OFF de TC, Bancos y Cuotas General (En construcción)';

            var getInput=function(input){
                  return  HaloService.getHotelList({
                       'limit' : 10,
                       'offset' : 0,
                       'name' : input,
                       'completenessFrom' : 0,
                       'completenessTo' : 100
                  }).$promise.then(function(data){

                    if (data.length === 0) {
                      var noResults = {'code':-1, 'hotelName' : 'No hay hoteles'};
                      data.push(noResults);
                    }

                    return data;
                  });
            };

            var autocomplete = {'name':'autocompleteHotel',
                              'getInput':getInput,
                              'key':'code',
                              'value':'hotelName',
                              'firstValue':'code'};

           var selectBank =  {'name':'select',
                              'options':'bancos',
                              'key':'id',
                              'value':'name'
                        };

            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};

           var selectCreditCard = {'name':'select',
                              'options':'tarjetas',
                              'key':'id',
                              'value':'name'
                        };

            $scope.columns =  [ {'name':'Hotel',
                                  'id':'hotelName',
                                  'type' : autocomplete,
                                  'bind' : 'hotelId',
                                  'editMode' : 'readOnly'
                                },
                                {'name':'Nombre del banco',
                                 'id':'bankName',
                                'type':selectBank,
                                'bind' : 'bankId'},
                                {'name':'Nombre de la tarjeta de crédito',
                                 'id':'creditCardName',
                                'type':selectCreditCard,
                                'bind' : 'creditCardId'},
                                {'name':'Cantidad de cuotas',
                                 'id':'installmentCount',
                                },
                                {'name':'Intereses',
                                 'id':'interest',
                                 'type':'percentage',
                                 'validator': Util.getInterestValidator()
                                },
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}
                                ];
                $scope.crudOperations =new CRUDService(CreditCardHotelsService,'ruleId');

            }
    });

})();

(function(){

    'use strict';

    angularApp.controller({'PaymentHomeController': function($scope) {                        
            $scope.rules=[
                    { 'id':1,
                     'name':'Métodos de Pago General',
                     'description':'Permite definir los métodos de pago válidos para todas las verticales(vuelos, hoteles, etc...)',
                     'viewUrl':'/commons-payment'
                    },
                    { 'id':2,
                     'name':'Métodos de Pago de Hoteles',
                     'description':'Permite definir los métodos de pago válidos para los hoteles',
                     'viewUrl':'/hotels-payment'
                    },
                    { 'id':3,
                     'name':'Tarjetas de Crédito General',
                     'description':'Permite definir las tarjetas de crédito válidas para todas las verticales(vuelos, hoteles, etc...)',
                     'viewUrl':'/commons-credit-cards'
                    },
					{ 'id':4,
		             'name':'Tarjetas de Crédito de Hoteles',
		             'description':'Permite definir las tarjetas de crédito válidas para todas los hoteles',
		             'viewUrl':'/hotels-credit-cards'
		            }
			];
    }});
        angularApp.config(['$routeProvider',
        function($routeProvider) {
            $routeProvider.
                when('/commons-payment', {
                    controller:'PaymentMethodCommonsController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
                }).
                when('/hotels-payment', {
                    controller:'PaymentMethodHotelesController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
                }).
                when('/commons-credit-cards', {
                    controller:'CreditCardCommonsController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
            	}).
                when('/commons-credit-cards/new', {
                    controller:'CreditCardCommonsAddController',
                    templateUrl:'views/hoteles-admin-ui/credit-card-add.html'
                }).
                when('/hotels-credit-cards', {
                    controller:'CreditCardHotelsController',
                    templateUrl:'views/hoteles-admin-ui/crud-view.html'
            	});
  }]);
})();

(function(){

    'use strict';

    angularApp.controller({'PaymentMethodCommonsController': function(Util, PaymentMethodCommonsService,CRUDService,limitToFilter, HaloService, $scope) {
            $scope.name = 'ON/OFF Métodos de Pago General (En construcción)';
            $scope.description = 'En este administrador se detallan los horarios de filtrado por metodo de pago. Si no se especifica los mismos estaran disponibles';


            var selectPaymentMethod = {'name':'select',
                              'options':'mediosDePago',
                              'key':'id',
                              'value':'name'
                        };

            var date = {'name':'date',
                        'format':'yyyy-MM-dd'};

            $scope.columns =  [  {'name':'Método de pago',
                                 'id':'paymentMethodTypeName',
                                'type':selectPaymentMethod,
                                'bind' : 'paymentMethodTypeId'},
                                {'name':'Fecha Desde',
                                 'id':'startDate',
                                 'type':date},
                                {'name':'Fecha Hasta',
                                 'id':'finishDate',
                                 'type':date}  ];
            $scope.crudOperations =new CRUDService(PaymentMethodCommonsService,'ruleId');

            }
    });

})();

(function(){

    'use strict';

    angularApp.controller({'PaymentMethodHotelesController': function(Util, PaymentMethodHotelesService,CRUDService,limitToFilter, HaloService, $scope) {
            $scope.name = 'ON/OFF Métodos de Pago de Hoteles (En construcción)';

              var selectPaymentMethod = {'name':'select',
                              'options':'mediosDePago',
                              'key':'id',
                              'value':'name'
                        };

            $scope.columns =  [ {'name':'Método de pago',
                                 'id':'paymentMethodTypeName',
                                'type':selectPaymentMethod,
                                'bind' : 'paymentMethodTypeId'}];
                  $scope.crudOperations =new CRUDService(PaymentMethodHotelesService,'ruleId');

            }
    });

})();

(function() {

    'use strict';

    angularApp.controller({
        'ReporteMargenDestinoController': function($scope, config) {
            $scope.name = 'Reporte de Magenes por Destinos';
            var today = moment();
            $scope.obj = {
                fechaDesde: today
            };
            $scope.makeUrl = function() {
                var path = config['hoteles-admin-ui']['product-manager-url'] + 'reportes/margen_destino?date=' + $scope.obj.fechaDesde.format();
                return path;
            };
        }
    });

})();

(function() {
    'use strict';

    angularApp.factory('Util',['config', function(config){
            var validateDiscount= function(value){
                  return value<=1 && value>=0;
            }; 
            var validateMarkup= function(value){
                  return value<=10 && value>=0;
            };
            var validateGCA= function(value){
                  var valorSistemaGCA = config['hoteles-admin-ui']['gca-percent'];
                  return value<=valorSistemaGCA && value>=0;
            };

            
             var Util= {
                    getDiscountValidator : function(){
                                          var validation = {'message':'Expresar como valor entre 0 y 100',
                                                            'action':validateDiscount
                                            };
                                      return validation;
                        },
                    getMarkUpValidator: function(){
                                          var validation = {'message':'Expresar como valor entre 0 y 1000',
                                                            'action':validateMarkup
                                            };
                                      return validation;

                      },
                    getInterestValidator: function(){
                                          var validation = {'message':'Expresar como valor entre 0 y 100',
                                                            'action':validateDiscount
                                            };
                                      return validation;
                    },
                    getGCAValidator: function(){
                                          var validation = {'message':'Expresar como valor entre 0 y el valor del sistema GCA',
                                                            'action':validateGCA
                                            };
                                      return validation;
                    }                   
                     
                     
            };

            return Util;
      }]);

})();   
(function() {
    'use strict';

    angularApp.factory('CRUDValidator',[function(){           
        return function(columns){

        function createError(id,value){
             return {'id':id,'value':value};   
        }
           
        function drawListOfErrors(errors){
                $.each(errors, function (index,value) {
                              drawErrorMessage(value.id,value.value);
                });         
        }
             
        function drawErrorMessage(id,value){
                var messageId='errorMessage_'+id;
                $('#'+messageId).text(value);
        }

        function validetaDates(object,errors,divId){
          var startDate =new Date(object.startDate);
          var finishDate=new Date(object.finishDate);
            if(finishDate.getTime() <= startDate.getTime()){
              errors.push(createError(divId+'_startDate','Fecha Invalida')); 
            }
        }

        function validateGCA(object,errors,divId){
         if(object.installmentCount < 2 &&  object.gcaPercent > 0){
            errors.push(createError(divId+'_gcaPercent','Para una cuota, el GCA debe ser cero.')); 
          }
        }

        var validations= [];
        $.each(columns, function (index,value) {
             if(value.validator!==undefined){
                validations[value.id]=value.validator;
                }
         });


          function validateAnInput(divId,objectToValidate,input){
            var errors=[];
            var inputName=$(input).attr('name');
            var propertyId = inputName.replace(divId+'_','');
            var validation=validations[propertyId];
            var viewValue=$(input).val();
       

            if($(input).is('select')){
              viewValue=$(input).find('option:selected').text();
            }
            if(validation!==undefined){
                  if(!validation.action(objectToValidate[propertyId])){
                     errors.push(createError(inputName,validation.message));  
                 }
            }else{
              if(viewValue.indexOf(objectToValidate[propertyId]) < 0) {
                 errors.push(createError(inputName,'Valor invalido'));
               }
            }
            drawErrorMessage(inputName,'');
            return errors;                                     
           }

          function isObjectValid(divId , objectToValidate){
                            var allErrors=[];
                            $('#'+divId+' input:text,'+'#'+divId+' select').each(function(){
                                var errors=validateAnInput(divId, objectToValidate, this);
                                allErrors=$.merge(allErrors,errors);
                                
                            });
                            validetaDates(objectToValidate,allErrors,divId);
                            validateGCA(objectToValidate,allErrors,divId);
                            drawListOfErrors(allErrors);
                            return allErrors.length===0;
               }


           function cleanInputValues(){
                                        $('#addRule input').each(function(){
                                            var inputName=$(this).attr('name');
                                            $(this).val('');
                                            drawErrorMessage(inputName,'');
                                        });
                                        $('#addRule select').each(function(){
                                            var inputName=$(this).attr('name');
                                            $(this).val('');
                                            drawErrorMessage(inputName,'');
                                        });
            }

            function validateInputOnBlur(divId,objectToValidate,input){
                               var errors=validateAnInput(divId, objectToValidate, input);
                               drawListOfErrors(errors);
            }  

            return {
              isObjectValid: isObjectValid,
              validateInputOnBlur: validateInputOnBlur,
              cleanInputValues: cleanInputValues
            };

        };

        }]);
})();   
(function() {

    'use strict';

    angularApp.directive('crudTable', ['CRUDValidator', function(CRUDValidator) {  
        return {    
            restrict: 'AE',
                replace: false,
            templateUrl: '/views/hoteles-admin-ui/template/crud-table-directive-template.html',
            scope: {
                columns: '=',
                crudoperations: '=',
                order: '=',
            },
            controller: ['$scope', '$rootScope', 'DidadiConstant', '$location', function($scope, $rootScope, DidadiConstant, $location) {
                $scope.objects = [];
                $scope.addMode = false;
                $scope.activate = false;
                $scope.priorityMode = false;
                $scope.filters = {};
                $scope.object = {};
                $scope.aux = {};
                $scope.orderBy = {};
                $scope.selectedProvider = '';
                $scope.selectedBank = '';
                $scope.selectedPaymentMethod = '';
                $scope.validator = new CRUDValidator($scope.columns);
                $scope.pageSize = 10;

                moment.locale('es');

                if ($scope.crudoperations.onDelete) {
                    $scope.deleteableMode = true;
                }
                if ($scope.crudoperations.onCreate) {
                    $scope.creatableMode = true;
                }
                if ($scope.crudoperations.onListAllObjects) {
                    $scope.showActiveMode = true;
                }
                if ($scope.crudoperations.onOrderPriority) {
                    $scope.priorityMode = true;
                }

                var allOpt = {
                    'id': 'ALL',
                    'label': 'Todos'
                };

                $scope.getOptions = function(name, allOption) {
                    if (name !== undefined) {
                        var didadi = DidadiConstant[name]();
                        return allOption ? _.union([allOpt], didadi) : didadi;
                    }
                    return [];
                };

                $scope.getSelectedValue = function(object, column) {
                    var opt = '';
                    var didadi = DidadiConstant[column.type.options]();
                    var options = column.type.allOption ? _.union([allOpt], didadi) : didadi;
                    options.forEach(function(option) {
                        if (option[column.type.value] === object[column.id] &&
                            option[column.type.key] === object[column.bind]) {
                            opt = option;

                        }
                    });
                    return opt;
                };

                $scope.update = function(value, object, column) {
                    if (value !== undefined) {
                        object[column.bind] = value[column.type.key];
                        object[column.id] = value[column.type.value];
                    }
                };

                $scope.toggleAddMode = function() {

                    //Hack para saltar el compartamiento si estoy en Financiación Bulk (/commons-credit-cards)
                    if($location.path() === '/commons-credit-cards'){
                        $location.path('/commons-credit-cards/new');
                    } else {
                        $scope.addMode = !$scope.addMode;
                        $scope.object = {};
                        $scope.validator.cleanInputValues();
                    }
                };


                $scope.setOrderBy = function(field) {
                    var asc = $scope.orderBy.field === field ? !$scope.orderBy.asc : true;
                    $scope.orderBy = {
                        field: field,
                        asc: asc
                    };
                };

                $scope.objectCopied = {};

                $scope.toggleEditMode = function(object) {
                    console.log('toggleEditMode', object);
                    object.editMode = !object.editMode;
                    var index = $scope.objects.indexOf(object);
                    $scope.objectCopied[index] = _.clone(object);
                };
                $scope.resetObjectValues = function(object) {
                    var index = $scope.objects.indexOf(object);
                    object = $scope.objectCopied[index];

                    $scope.objects[index] = object;
                    object.editMode = !object.editMode;
                };




                $scope.createObject = function(addRuleDivId, lastPriority) {
                    // Al crear una instancia, debo pasarle la prioridad (para reglas de location).
                    // Le seteo la ultima prioridad +1.
                    if (lastPriority !== null) {
                        $scope.object.priority = lastPriority + 1;
                    }
                    if ($scope.validator.isObjectValid(addRuleDivId, $scope.object)) {

                        $('#addRule :input').attr('disabled', true);
                        $scope.crudoperations.onCreate(
                            $scope.object,
                            function(object, message) {
                                $scope.objects.push($scope.object);
                                $scope.object = {};
                                $scope.aux = {};
                                $scope.toggleAddMode();
                                showSuccessMessage(message);
                                $('#addRule :input').attr('disabled', false);
                            },
                            function(message) {
                                showErrorMessage(message);
                                $('#addRule :input').attr('disabled', false);
                            });
                    }
                };

                $scope.listObjects = function() {
                    $scope.objects = [];
                    $scope.crudoperations.onList(function(data, message) {
                        $scope.objects = data;
                        $scope.orderBy = {
                            field: 'active',
                            asc: true
                        };
                        console.log(message);
                        //$scope.showErrorMessage(message);
                    }, showErrorMessage);
                };

                $scope.listObjects();

                $scope.deleteObject = function(object) {
                    $scope.crudoperations.onDelete(object, function(data, message) {
                        object.active = 'false';
                        if (!$scope.activate) {
                            var index = $scope.objects.indexOf(object);
                            $scope.objects.splice(index, 1);
                        }
                        showSuccessMessage(message);
                    }, showErrorMessage);
                };
                $scope.listAllObjects = function() {
                    $scope.activate = ($scope.activate === false) ? true : false;
                    if ($scope.activate) {
                        $scope.crudoperations.onListAllObjects(function(data, message) {
                            $scope.objects = data;
                            //$scope.showSuccessMessage(message);
                            console.log(message);
                        }, showErrorMessage);
                    } else {
                        $scope.listObjects();
                    }
                };
                $scope.activateObject = function(object) {
                    $scope.crudoperations.activateObject(object, function(data, message) {
                        object.active = 'true';
                        showSuccessMessage(message);
                    }, showErrorMessage);
                };

                //CRUD
                $scope.updateObject = function(object, divId) {

                    if ($scope.validator.isObjectValid(divId, object)) {
                        var objectToUpdate = _.omit(object, 'editMode');
                        $scope.crudoperations.onUpdate(objectToUpdate,
                            function(data, message) {
                                object.editMode = !object.editMode;
                                showSuccessMessage(message);
                            },
                            function(message) {
                                showErrorMessage(message);
                                //$scope.listAllObjects();
                            });
                    }
                };

                $scope.selectResult = function(itemSelected, object, column) {
                    if (itemSelected[column.type.key] !== -1) {
                        if (itemSelected[column.type.firstValue] !== undefined) {
                            object[column.id] = itemSelected[column.type.firstValue] + ' - ' + itemSelected[column.type.value];
                        } else {
                            object[column.id] = itemSelected[column.type.value];
                        }
                        if (column.bind) {
                            object[column.bind] = itemSelected[column.type.key];
                        }
                    }

                };

                $scope.formatLabel = function(input, column) {
                    if (input && column.type.key && input[column.type.key] !== -1) {
                        if (input[column.type.firstValue] !== undefined) {
                            return input[column.type.firstValue] + ' - ' + input[column.type.value];
                        } else {
                            return input[column.type.value];
                        }
                    }
                    return '';
                };

                $scope.parseDate = function(date, object, id) {
                    object[id] = moment(new Date(date)).format('YYYY-MM-DD HH:mm');
                };

                $scope.validate = function(divId, object, input) {
                    $scope.validator.validateInputOnBlur(divId, object, $('#' + divId + ' [name=' + input + ']'));
                };
                $scope.persistPriorities = function() {
                    var elements = $scope.objects.map(function(element) {
                        var reindexedElement = {
                            ruleId: element.ruleId,
                            priority: element.priority
                        };
                        return reindexedElement;
                    });
                    $scope.$broadcast('close_alerts');
                    $scope.crudoperations.onPersistPriorities(elements,
                        function(data, message) {
                            showSuccessMessage(message);
                        },
                        function(message) {
                            showErrorMessage(message);
                            $scope.listObjects();
                        });

                };
                $scope.eventCancellation = function(event) {
                    event.preventDefault();
                };
                $scope.getLastPriority = function() {
                    var maxPriority = null;
                    $scope.objects.forEach(function(element) {
                        if (maxPriority < element.priority || maxPriority === null) {
                            maxPriority = element.priority;
                        }
                    });
                    return parseInt(maxPriority);
                };

                $scope.dragStart = function(event) {
                    if ($scope.priorityMode) {
                        $scope.draggedRule = event.srcElement.id;
                    }
                };
                $scope.dropThis = function(event) {
                    if ($scope.priorityMode) {
                        $scope.$broadcast('close_alerts');
                        $scope.$broadcast('new_alert', {
                            type: 'warning',
                            msg: 'Recordá por favor guardar los cambios'
                        });

                        var reorderingFunction = function() {
                            var srcName = $scope.draggedRule;
                            var destName = '';

                            //It has to be done like this because event path get nodeList DOM objects
                            for (var i = 0; i < event.path.length; i++) {
                                if (event.path[i].nodeName === 'TR') {
                                    destName = event.path[i].getAttribute('id');
                                }
                            }
                            //Objeto a cambiar de lugar
                            var srcId = srcName.replace('rule', '');
                            var destId = destName.replace('rule', '');

                            //Cambio de lugar los objetos y seteo la prioridad correspondiente.
                            var srcPriority = $scope.objects[srcId].priority;
                            var destPriority = $scope.objects[destId].priority;
                            var aux = $scope.objects[destId];

                            $scope.objects[destId] = $scope.objects[srcId];
                            $scope.objects[destId].priority = destPriority;
                            $scope.objects[srcId] = aux;
                            $scope.objects[srcId].priority = srcPriority;
                        };
                        $scope.$apply(reorderingFunction);
                    }
                };

                var showErrorMessage = function(message) {
                    $scope.$broadcast('close_alerts');
                    $scope.$broadcast('new_alert', {
                        type: 'danger',
                        msg: message
                    });
                };
                var showSuccessMessage = function(message) {
                    $scope.$broadcast('close_alerts');
                    $scope.$broadcast('new_alert', {
                        type: 'success',
                        msg: message
                    });
                };


                $scope.markupToPercentage = function(markup) {
                    return parseFloat(markup) * 100 + '%';
                };
            }]    
        };
    }]);

    /******************** DatePicker *******************/
    angularApp.directive('tarjetasDatetimepicker', function() {
        var format = 'YYYY-MM-DD HH:mm';

        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, element, attributes, ctrl) {
                element.datetimepicker({
                    format: format,
                    sideBySide: true

                });
                var picker = element.data('DateTimePicker');

                ctrl.$formatters.push(function(value) {
                    var aux = value.match(/^(\d+)\/(\d+)\/(\d+) (\d+)\:(\d+)$/);
                    var date = moment(new Date(aux[3], aux[2] - 1, aux[1], aux[4], aux[5], '00'));
                    if (date.isValid()) {
                        return date.format(format);
                    }
                    return '';
                });

                element.on('dp.change', function() {
                    scope.$apply(function() {
                        var date = picker.viewDate();
                        ctrl.$setViewValue(date.valueOf());
                    });
                });
            }
        };
    });
})();

(function() {

    'use strict';


    /******************** DatePicker *******************/
    angularApp.directive('hotelesDatetimepicker', function() {
        var format = 'DD/MM/YYYY HH:mm';

        return {
            restrict: 'A',
            require: '?ngModel',
            link: function(scope, element, attributes, ctrl) {
                element.datetimepicker({
                    defaultDate: attributes.defaultdate,
                    format: format,
                    sideBySide: true

                });
                var picker = element.data('DateTimePicker');

                setTimeout(function() {
                    if(ctrl.$modelValue) {
                        picker.date( ctrl.$modelValue );
                    }
                });

                ctrl.$formatters.push(function(value) {
                    var date = moment(value);
                    if (date.isValid()) {
                        return date;
                    }
                    return '';
                });

                element.on('dp.change', function() {
                    scope.$apply(function() {
                        var date = picker.viewDate();
                        ctrl.$setViewValue(date);
                    });
                });

            }
        };
    });


})();

//Pasar a berazategui  !!!
    'use strict';
angularApp.directive(
    'ngDragNDrop',
    function() {
        return {
            restrict: 'A',
            scope: {
                behavior: '@ngDrag',
                ngDraggable: '@',
                ngDroppable: '@',
                ngDragstart: '=',
                ngDragend: '=',
                ngEffectAllowed: '@',
                ngDragenter: '=',
                ngDragover: '=',
                ngDragleave: '=',
                ngDrop: '=',
                ngDropEffect: '@'
            },
            link: function(scope, element) {
                /* choose behavior */
                var draggable = scope.ngDraggable === 'true';
                var droppable = scope.ngDroppable === 'true';

                function makeItDraggable(scope, element) {
                    /* make it draggable */

                    element.css({
                        position: 'relative',
                    });

                    element.attr('draggable', true);

                    /* bind draggable event handlers */
                    element.on('dragstart', function(event) {
                        /* some posibilities for css */
                        var bEvent = scope.getMouseEvent(event);
                        element.addClass('ng-draggable-on-drag');

                        var effectAllowed = 'move';
                        if (angular.isDefined(scope.ngEffectAllowed)) {
                            effectAllowed = scope.ngEffectAllowed;
                        }
                        bEvent.effectAllowed = effectAllowed;

                        if (angular.isDefined(scope.ngDragstart)) {
                            if (angular.isArray(scope.ngDragstart)) {
                                var parameters = scope.ngDragstart.slice();
                                var handler = parameters.shift();
                                parameters.unshift(bEvent);
                                handler.apply(this, parameters);
                            } else {
                                scope.ngDragstart(bEvent);
                            }
                        }

                    });

                    element.on('dragend', function(event) {
                        /* some css */
                        element.removeClass('ng-draggable-on-drag');

                        var bEvent = scope.getMouseEvent(event);

                        if (angular.isDefined(scope.ngDragend)) {
                            if (angular.isArray(scope.ngDragend)) {
                                var parameters = scope.ngDragend.slice();
                                var handler = parameters.shift();
                                parameters.unshift(bEvent);
                                handler.apply(this, parameters);
                            } else {
                                scope.ngDragend(bEvent);
                            }
                        }
                    });
                }

                function makeItDroppable(scope, element) {

                    element.on('dragenter', function(event) {
                        
                        var bEvent = scope.getMouseEvent(event);
                        /* some css */
                        element.addClass('ng-droppable-on-sight');

                        if (angular.isDefined(scope.ngDragenter)) {
                            if (angular.isArray(scope.ngDragenter)) {
                                var parameters = scope.ngDragenter.slice();
                                var handler = parameters.shift();
                                parameters.unshift(bEvent);
                                handler.apply(this, parameters);
                            } else {
                                scope.ngDragenter(bEvent);
                            }
                        }
                    });

                    element.on('dragover', function(event) {

                        var dropEffect = 'move';
                        if (angular.isDefined(scope.ngDropEffect)) {
                            dropEffect = scope.ngDropEffect;
                        }

                        var bEvent = scope.getMouseEvent(event);

                        bEvent.dataTransfer.dropEffect = dropEffect;

                        if (angular.isDefined(scope.ngDragover)) {
                            if (angular.isArray(scope.ngDragover)) {
                                var parameters = scope.ngDragover.slice();
                                var handler = parameters.shift();
                                parameters.unshift(bEvent);
                                handler.apply(this, parameters);
                            } else {
                                scope.ngDragover(bEvent);
                            }
                        }
                    });

                    element.on('dragleave', function(event) {

                        var bEvent = scope.getMouseEvent(event);
                        /* some css */
                        element.removeClass('ng-droppable-on-sight');

                        if (angular.isDefined(scope.ngDragleave)) {
                            if (angular.isArray(scope.ngDragleave)) {
                                var parameters = scope.ngDragleave.slice();
                                var handler = parameters.shift();
                                parameters.unshift(bEvent);
                                handler.apply(this, parameters);
                            } else {
                                scope.ngDragleave(bEvent);
                            }
                        }
                    });

                    element.on('drop', function(event) {
                        /* some css */
                        var bEvent = scope.getMouseEvent(event);
                        element.removeClass('ng-droppable-on-sight');
                        if (angular.isDefined(scope.ngDrop)) {
                            if (angular.isArray(scope.ngDrop)) {
                                var parameters = scope.ngDrop.slice();
                                var handler = parameters.shift();
                                parameters.unshift(bEvent);
                                handler.apply(this, parameters);
                            } else {
                                scope.ngDrop(bEvent);
                            }
                        }
                    });
                }

                if (scope.behavior === 'all' || (draggable && droppable)) {

                    makeItDroppable(scope, element);
                    makeItDraggable(scope, element);

                } else if (scope.behavior === 'draggable' || draggable) {

                    makeItDraggable(scope, element);

                } else if (scope.behavior === 'droppable' || droppable) {

                    makeItDroppable(scope, element);

                }

                scope.getMouseEvent = function(event) {
                    var bEvent = event;
                    if (!(event instanceof MouseEvent) && angular.isDefined(event.originalEvent)) {
                        bEvent = event.originalEvent;
                    }
                    return bEvent;
                };
            }
        };
});
(function(){

    'use strict';

angularApp.directive('percentage', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, element, attr, ngModel) {

            function fromUser(value) {
                return parseFloat(value)/100+'';
            }

            function toUser(value) {
                return parseFloat(value)*100+'';
            }

            ngModel.$parsers.push(fromUser);
            ngModel.$formatters.push(toUser);
        }
    };
});

})();


(function() {
    'use strict';

    angularApp.factory('CRUDService', [function(){

        var  CrudService = function(service,objectId) {
            this.service = service;
            this.objectId=objectId;
        };

        CrudService.prototype.onUpdate= function(object, onSuccess, onError){
            this.service.update(object,function(data){
               if(data.notification!==undefined && data.notification.indexOf('Error')!==-1){
                     onError(data.notification);
               }else{
                     onSuccess(object,'Regla actualizada correctamente.');  
               }
            },
            function(){
                onError('Error al actualizar la regla.');
            });                      
        };
        CrudService.prototype.onCreate= function(object, onSuccess, onError){
            this.service.create(object).$promise.then(function(data){
                if(data.notification!==undefined && data.notification.indexOf('Error')!==-1){
                     onError(data.notification);
               }else{
                    onSuccess(object,'Regla creada correctamente.');
               }
            },function(){
                onError('Error al crear la regla.');
            });
        };

        /*Financiación Custom*/
        CrudService.prototype.onCreateCustom= function(object, onSuccess, onError){
            this.service.create(object).$promise.then(function(data){
                if(data.status!==undefined && data.status.indexOf('ERROR')!==-1){
                    onError(data.rows);
                }else{
                    onSuccess(object,'Regla creada correctamente.');
                }
            },function(){
                onError('Error al crear la regla.');
            });
        };

        CrudService.prototype.onList=function(onSuccess, onError){
            this.service.list({}).$promise.then(function(data){
                onSuccess(data,'Reglas cargadas correctamente');            
            }, function(){
                onError('Error al cargar las reglas.');
            });
        };
        CrudService.prototype.onDelete=function(object, onSuccess, onError){
            var data = {
                id: object[this.objectId]
            };
            this.service.delete(data,
            function(){
                onSuccess({},'Regla borrada correctamente.');   
            },function(){
                onError('Error al eliminar la regla.');
            });
        };
        CrudService.prototype.onListAllObjects=function(onSuccess, onError){
            this.service.listAll({}).$promise.then(function(data){
                onSuccess(data,'Reglas cargadas correctamente.');            
            }, function(){
                onError('Error al cargar las reglas.');
            });
        };
        CrudService.prototype.onPersistPriorities= function(object, onSuccess, onError){
            this.service.persistPriorities(object,function(){
                onSuccess(object,'Prioridad actualizada correctamente.');         
            },
            function(){
                onError('Error al actualizar prioridad.');
            });                      
        };
        CrudService.prototype.activateObject=function(object, onSucces, onError){
            var data = {
                id: object[this.objectId]
            };
            this.service.activate(data,
                function(data){
                if(data.notification!==undefined && data.notification.indexOf('Error')!==-1){
                         onError(data.notification);
                   }else{
                         onSucces({},'Regla activada correctamente.');  
                   }
                },function(){
                    onError('Error al activar la regla.');
                });
            };
            return  CrudService;    
         }]);
})();   
(function() {
    'use strict';

    var competenciaPath ='configs/Competition/Configurations.Competition.do-providers-competition';
    var prioridadPath ='configs/Competition/Configurations.Competition.providers-competition-priority';
    var configPath ='configs/';

    function createCrudService(url) {
        console.log(url);
        return function($resource, config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+url;
            return $resource(target, {}, {
                list: {
                    method: 'GET',
                    url:target+'Competition'
                },
                update: {
                    method: 'PUT',
                    url:target+'/:value'
                },
                listAll:{
                    method: 'GET',
                }
            });
        };
    }
    angularApp.factory('CompetenciaService', ['$resource', 'config', createCrudService(competenciaPath)]);
    angularApp.factory('PrioridadService', ['$resource', 'config', createCrudService(prioridadPath)]);
    angularApp.factory('ConfigService', ['$resource', 'config', createCrudService(configPath)]);

})();


(function() {
    'use strict';

    var discountHotelPath = 'discount_hotel';
    var discountLocationPath = 'location_discount';
    var discountProveedorPath = 'provider_discount';

    function createCrudService(url) {
        return function($resource, config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+url;
            return $resource(target,{id:'@id'}, {
                list: {
                    method: 'GET',
                    isArray: true,
                },
                update: {
                    method: 'PUT',
                    isArray: false,
                },
                create: {
                    method: 'POST',
                    isArray: false,
                },
                delete: {
                    method: 'DELETE',
                    isArray: false,
                    url: target + '/:id',
                },
                listAll:{
                    method: 'GET',
                    isArray:true,
                    url:target+'/all',
                },
                activate:{
                    method: 'PUT',
                    isArray: false,
                    url: target + '/activate/:id',                                   
                },
                persistPriorities:{
                    method: 'PUT',
                    isArray: true,
                    url: target + '/priority',
                }        
            });
        };
    }
    angularApp.factory('DiscountHotelService', ['$resource', 'config', createCrudService(discountHotelPath)]);
    angularApp.factory('DescuentoDestinoService', ['$resource', 'config', createCrudService(discountLocationPath)]);	
    angularApp.factory('DiscountProveedorService', ['$resource', 'config', createCrudService(discountProveedorPath)]);
})();   

(function() {
    'use strict';

    var locationVedada = 'locations_vedadas';
    var hotelFiltrado ='hoteles_filtrados';
    
    function createCrudService(url) {
        return function($resource, config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+url;
            return $resource(target, {id:'@id'}, {
                list: {
                    method: 'GET',
                    isArray: true,
                },
                update: {
                    method: 'PUT',
                    isArray: false,
                },
                create: {
                    method: 'POST',
                    isArray: false,
                },
                delete: {
                    method: 'DELETE',
                    isArray: false,
                    url: target + '/:id',
                },
                listAll:{
                    method: 'GET',
                    isArray:true,
                    url:target+'/all',
                },
                activate:{
                    method: 'PUT',
                    isArray: false,
                    url: target + '/activate/:id',
                },
                persistPriorities:{
                    method: 'PUT',
                    isArray: true,
                    url: target + '/priority',
                }    
            });

        };

    }
 	angularApp.factory('FiltroDestinoService', ['$resource', 'config', createCrudService(locationVedada)]);
    angularApp.factory('FiltroHotelService', ['$resource', 'config', createCrudService(hotelFiltrado)]);

})();	


(function() {

    'use strict';

 	var hotelesDestacadosUrl = 'hoteles_destacados';

 	
    angularApp.factory('HotelesDestacadosService', ['$resource', 'config',
        function($resource,config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+hotelesDestacadosUrl;
            return $resource(target, {id:'@id'}, {
                list: {
                    method: 'GET',
                    isArray: true,                                      
                },
                delete: {
                    method: 'DELETE',
                    url: target + '/:id'
                },
                update: {
                    method: 'PUT',
                    isArray: false,
                    url: target + ':hotelDestacadoDTO'
                },
                create: {
                    method: 'POST',
                    isArray: false,
                },
                listAll:{
                    method: 'GET',
                    isArray:true,
                    url:target+'/all',
                },
                activate:{
                    method: 'PUT',
                    isArray: false,
                    url: target + '/activate/:id',
                }        

            });
        }
    ]);

})();	


(function() {
    'use strict';

    var markupLocationPath ='markup_location';
    var markupHotelPath = 'markup_hotel';
    var markupDefaultPath ='markup_default';
    var markupProveedorPath ='markup_proveedor';
    var markupOnTaxesForProviderPath ='markup_on_taxes_provider';
    var markupOnTaxesForHotelPath ='markup_on_taxes_hotel';
    var markupOnTaxesForLocationPath ='markup_on_taxes_location';
    var markupOnTaxesDefaultPath ='markup_on_taxes_default';

    function createCrudService(url) {
        console.log(url);
        return function($resource, config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+url;
            return $resource(target, {id:'@id'}, {
                list: {
                    method: 'GET',
                    isArray: true,
                },
                update: {
                    method: 'PUT',
                    isArray: false,
                },
                create: {
                    method: 'POST',
                    isArray: false,
                },
                delete: {
                    method: 'DELETE',
                    isArray: false,
                    url: target + '/:id',
                },
                listAll:{
                    method: 'GET',
                    isArray:true,
                    url:target+'/all',
                },
                activate:{
                    method: 'PUT',
                    isArray: false,
                    url: target + '/activate/:id',
                },
                persistPriorities:{
                    method: 'PUT',
                    isArray: true,
                    url: target + '/priority',
                }     
            });
        };
    }
    angularApp.factory('MarkupHotelService', ['$resource', 'config', createCrudService(markupHotelPath)]);
    angularApp.factory('MarkupDefaultService', ['$resource', 'config', createCrudService(markupDefaultPath)]);
    angularApp.factory('MarkupLocationService', ['$resource', 'config', createCrudService(markupLocationPath)]);
    angularApp.factory('MarkupProveedorService', ['$resource', 'config', createCrudService(markupProveedorPath)]);
    angularApp.factory('MarkupOnTaxesForProviderService', ['$resource', 'config', createCrudService(markupOnTaxesForProviderPath)]);
    angularApp.factory('MarkupOnTaxesForHotelService', ['$resource', 'config', createCrudService(markupOnTaxesForHotelPath)]);
    angularApp.factory('MarkupOnTaxesForLocationService', ['$resource', 'config', createCrudService(markupOnTaxesForLocationPath)]);
    angularApp.factory('MarkupOnTaxesDefaultService', ['$resource', 'config', createCrudService(markupOnTaxesDefaultPath)]);
})();   

(function() {
    'use strict';

    var paymentMethodTypeCommonsPath ='payment_method_type_commons';
    var paymentMethodTypePath = 'payment_method_type';
    var creditCardCommonsPath ='credit_card_commons';
    var creditCardCommonsOnHotelPath ='credit_card_commons_on_hotel';

    function createCrudService(url) {
        console.log(url);
        return function($resource, config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+url;
            return $resource(target, {id:'@id'}, {
                list: {
                    method: 'GET',
                    isArray: true,
                },
                update: {
                    method: 'PUT',
                    isArray: false,
                },
                create: {
                    method: 'POST',
                    isArray: false,
                },
                delete: {
                    method: 'DELETE',
                    isArray: false,
                    url: target + '/:id',
                },
                listAll:{
                    method: 'GET',
                    isArray:true,
                    url:target+'/all',
                },
                activate:{
                    method: 'PUT',
                    isArray: false,
                    url: target + '/activate/:id',
                },
                persistPriorities:{
                    method: 'PUT',
                    isArray: true,
                    url: target + '/priority',
                }     
            });
        };
    }
    angularApp.factory('PaymentMethodCommonsService', ['$resource', 'config', createCrudService(paymentMethodTypeCommonsPath)]);
    angularApp.factory('PaymentMethodHotelesService', ['$resource', 'config', createCrudService(paymentMethodTypePath)]);
    angularApp.factory('CreditCardCommonsService', ['$resource', 'config', createCrudService(creditCardCommonsPath)]);
    angularApp.factory('CreditCardHotelsService', ['$resource', 'config', createCrudService(creditCardCommonsOnHotelPath)]);
})();   

(function() {

    'use strict';

    //from berazategui:
    var didadiEndpoint = Avantrip.getConfig().didadiEndpoint;
    var dd = new DidadiClient(didadiEndpoint.host + ':'+didadiEndpoint.port);

    //find All:

    var cache = {};

    function fetch(c) {
        cache[c] = [];
        dd.getCollection(c, {}, function(value){ 
            cache[c] = value;
          }, 
          function(err){ console.log(err); 
        });

    }

    ['gds', 'bancos','tarjetas','medios_de_pago'].forEach(fetch);

        /*
    dd.getCollections(function(col){ 
        console.log(col); 
 
        col.forEach(fetch);

      }, 
      function(err){ console.log(err); 
    });
    */

    function get(key) {
        return cache[key] || [];
    }

    angularApp.service('DidadiConstant', function(){  
      return {
        cache: function() { return cache; },
        providers: function() { return get('gds'); },
        bancos: function() {    return get('bancos'); },
        tarjetas: function() {    return get('tarjetas'); },
        mediosDePago: function() {  return get('medios_de_pago');    },
      };
    });
})();   
(function() {

    'use strict';

    angularApp.factory('HaloService', ['$resource','config',
        function($resource,config) {
            var haloRestLocation = config['hoteles-admin-ui']['halo-url'];
            console.log('url: ' + haloRestLocation + '/hotels/finder');
            return $resource(haloRestLocation, {}, {
                getHotelList: {
                    method: 'GET',
                    isArray: true,
                    url: haloRestLocation +'/hotels/finder',
                    transformResponse: function (data) {
                        var results = [];
                        JSON.parse(data).data.forEach(function(element){
                             console.log('Ingreso en el for', element);
                             var providers = '';
                             if('@EXP' in element.providers){
                                providers = providers + 'Expedia '; 
                             }
                             if('@HDO' in element.providers){
                                providers = providers + 'HotelDo '; 
                             }
                             if('@HBED' in element.providers){
                                providers = providers + 'HotelBeds '; 
                             }
                             console.log('element', element.providers);
                             console.log('code', element.code);
                             console.log('hotelName', element.hotelName._es);
                             var result = {'code' : element.code, 'hotelName' : element.hotelName._es + ' - ' + providers + ' - ' + element.location.locationmanager.lmpath.label};
                             results.push(result); 
                        });
                        return results;
                    },
                }  
            });
        }
    ]);

})();	


(function() {

    'use strict';

    angularApp.factory('LomaSearchService', ['$resource','config',
        function($resource,config) {
            var lomaRestLocation = config['hoteles-admin-ui']['loma-url'];
            return $resource(lomaRestLocation, {}, {
                getLocations: {
                    method: 'GET',
                    isArray: false,
                    url: lomaRestLocation +'?lang=es&search=:search'
                },
                getParentsByIds: {
                    method: 'GET',
                    isArray: false,
                    url: lomaRestLocation +'?lang=es&downdegree=1&nodeIds=:nodeIds'
                },
                getParentsById: {
                    method: 'GET',
                    isArray: false,
                    url: lomaRestLocation +'?lang=es&downdegree=1&nodeIds=:nodeIds'
                }
            });
        }
    ]);

    angularApp.service('LomaUtils', [ 'LomaSearchService',
        function( LomaSearchService ) {

            function converPath(path) {
                var redableList = _.map(path, function(n) {return n.label;} );
                var el = path[0];

                return {
                    id: el.id,
                    label: redableList.join(', ')
                };
            }
            
            function createRedablePath(data) {
                return data.paths ? _.map(data.paths, converPath) : []; 
            }

            function find(criteria) {

                var p = LomaSearchService.getLocations({
                    'search' : criteria
                }).$promise; 
 
                return p.then(createRedablePath);
            }

            function getParentsById(id) {
                var p = LomaSearchService.getParentsById({
                    'nodeIds' : id
                }).$promise; 
 
                return p.then(function(data) {
                    if(data.paths && data.paths[0]) {
                        var path = data.paths[0];
                        var i = 0;
                        while(path[i].id !== id) {
                            i++;
                        }
                        path = path.slice(i);
                        var converted = converPath(path);
                        converted.locationName = path[0].label;
                        return [converted];
                    } else {
                        return [];
                    }
                });
            }


            //public api
            var api = {};

            api.findByName = function(text) { return find(text); };

            api.getParentsById = function(id) { return getParentsById(id); };

            api.createRedablePath = createRedablePath;

            return api;
        }
    ]);

})();	

(function() {
    'use strict';

    var marginLocationPath = 'margin_location';

    function createCrudService(url) {
        return function($resource, config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+url;
            return $resource(target, {id:'@id'}, {
                list: {
                    method: 'GET',
                    isArray: true,
                },
                update: {
                    method: 'PUT',
                    isArray: false,
                },
                create: {
                    method: 'POST',
                    isArray: false,
                },
                delete: {
                    method: 'DELETE',
                    isArray: false,
                    url: target + '/:id',
                },
                listAll:{
                    method: 'GET',
                    isArray:true,
                    url:target+'/all',
                },
                activate:{
                    method: 'PUT',
                    isArray: false,
                    url: target + '/activate/:id',
                },
                persistPriorities:{
                    method: 'PUT',
                    isArray: true,
                    url: target + '/priority',
                },
                getByProvider:{
                    method: 'GET',
                    isArray: true,
                    url: target + '/provider/:id'
                },
                getByLocation: {
                    method: 'GET',
                    isArray: true,
                    url: target + '/location/:id'
                }
            });
        };
    }
    angularApp.factory('MarginLocationService', ['$resource', 'config', createCrudService(marginLocationPath)]);
})();   

(function() {
    'use strict';

    var marginProviderPath = 'margin_provider';

    function createCrudService(url) {
        return function($resource, config) {
            var target = config['hoteles-admin-ui']['product-manager-url']+url;
            return $resource(target, {id:'@id'}, {
                list: {
                    method: 'GET',
                    isArray: true,
                },
                update: {
                    method: 'PUT',
                    isArray: false,
                },
                create: {
                    method: 'POST',
                    isArray: false,
                },
                delete: {
                    method: 'DELETE',
                    isArray: false,
                    url: target + '/:id',
                },
                listAll:{
                    method: 'GET',
                    isArray:true,
                    url:target+'/all',
                },
                activate:{
                    method: 'PUT',
                    isArray: false,
                    url: target + '/activate/:id',
                },
                persistPriorities:{
                    method: 'PUT',
                    isArray: true,
                    url: target + '/priority',
                },
                get: {
                    method: 'GET',
                    isArray: false,
                    url: target + '/:id'
                }     
            });
        };
    }
    angularApp.factory('MarginProviderService', ['$resource', 'config', createCrudService(marginProviderPath)]);
})();   



}; //end angular wrapper

//})();
