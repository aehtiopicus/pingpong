/* global Avantrip */
(function startApp() {

    'use strict';

    function addRoutes(routeProvider) {
        routeProvider
                .when('/', {
                    controller:'HomeCtrl',
                    templateUrl:'views/berazategui-home/home.html'
                })
                .otherwise({
                    redirectTo:'/'
                });
    }
/*
    function addMenu(menu) {

         menu.addMenu('Home', [{
            url: '#/',
            text: 'Home',
            order: -1,
            selected: true

        }]);

    }
*/
    function createAngularApp(app){
         
	app.controller('HomeCtrl', function($rootScope, $scope) {
  
            $scope.homeMessage =  ('-- HOME Loading --');
            
	    $rootScope.$watch('langBox.selected', function(newVal){
                if(newVal) {
                    $scope.homeMessage =  ('HOME language: "' + newVal.label + '"');
                }
	    });
             
            console.log('hello HomeCtrl');
        });

    }

    var testApp = {        
    };

    Avantrip.register('homeApp', testApp)
        .onLoad( function init(/*avt*/) {
		console.log('HOME Loaded');
	}  )
        .on('angularLoad', createAngularApp)
        .on('routeLoad', addRoutes)
       // .on('menuLoad', addMenu)
    ;    

})();
