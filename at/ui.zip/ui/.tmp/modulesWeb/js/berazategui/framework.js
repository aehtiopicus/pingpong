/* global $, _ */
var Avantrip = (function(){

    'use strict';

    //app
    var avantApp = {};

    var modules = {};

    var config = {
        loaded: false
    };

    var loadedFiles = [];

    function jsIsLoaded( file ) {

        return _.some( loadedFiles, function(f) { return f === file; } );
    }

    function setLoaded( file ) {
        loadedFiles.push(file);
    }

    function log(msg) {
        if(console && console.log) {
            console.log( msg );
        }
    }

    //scoped
    function createEventDispacher(target) {

	target._listeners = [];

	var fireEvent = function(event, dispacher) {
	    _.each(target._listeners,
		   function(listener){
		       if(listener.ev === event) {
			   dispacher(listener.fnc);
		       }
		   });
	};	    
	
	target.on = function(event, listenerFnc) {
            if (event) {
		target._listeners.push( { ev: event, fnc: listenerFnc } );
                
            } else {
                log('invalid event for listen');
            }

            return target;
	};

	target.fire = function(event, target) {

            //log('EVENT: ' + event);

	    if ($.isFunction(target)) {
		fireEvent(event, target);

	    } else {

                //fire framework events
		fireEvent( event, function(listenerFnc) { 
		    if (listenerFnc){
			listenerFnc(target);                        
		    } else if(console) {
			log('Invalid listener function for: ' + event);
		    }
		} );
 
                //angular hack:
                var deferedAngularCall = function() {
                    var scope = {$apply:function(){}, $$phase:true};
                    var root = {$broadcast:function(){}};

                    if($('body').scope && $('body').scope()){
                        scope = $('body').scope();
                        root = scope.$root;
                    }
                    
                    if(!scope.$$phase) {
                        scope.$apply(function(){
                            //log('berazategui.EVENT: ' + event);
                            root.$broadcast('berazategui.'+event, target);
                        });
                    } else {
                        //angular is bussy, call later;
                        setTimeout(deferedAngularCall, 100);
                    }
                };

                deferedAngularCall();

	    }	    
	};


        target.fireLater = function(event, etarget){
            setTimeout(function(){
               target.fire(event, etarget);
            }, 200);
            
        };

        return target;
    } //end createEventDispacher


    function fireModuleLoad(module){

        function load(module){
            if(config.loaded && module && !module._loaded) {
                
                if( module._onLoad){
                    module._onLoad(avantApp);
                }

                module._loaded = true;

                avantApp.fire('moduleLoaded', module);
            }
        }

        if(module) {
            load(module);
        } else {
            _.each(_.values(modules), load);
        }

    }

    //register module in main app
    function registerModule(name, module) {   

        if(!name || !module) {
            log('invalid module ' + name || module);
            return;
        }

        modules[name] = module;      
    }

    ///////

    //load base
    function load(conf, modulesFile) {

        function loadStyles(cssList, version) {
            
            if(!cssList) {
                return;
            }

            version = (version.indexOf('?') === -1  ? '?' : '') + version;

            cssList.forEach(function(file){
                log('Load CSS: ' + file + version);

                $('<link>')
                    .appendTo('head')
                    .attr({type : 'text/css', rel : 'stylesheet'})
                    .attr('href', '/styles/' + file + version);
                
            });

            
        }

        function loadModulesFrom(conf, callback) {

            log('Loading modules..');
 
            function getScript( url, options ) {

                // Allow user to set any option except for dataType, cache, and url
                options = $.extend( options || {}, {
                    dataType: 'script',
                    cache: !!!config.devMode,
                    url: url
                });
                // Use $.ajax() since it is more flexible than $.getScript
                // Return the jqXHR object so we can chain callbacks
                return $.ajax( options );
                
            }

            function loadModules(modules) {
                var next = modules.shift();

                if(!next){
                    callback();
                    return;
                } 

                //static files
                if(jsIsLoaded(next.file)) {
                    log('file is laoded: ' + next.file);
                    //next
                    loadModules( modules );
                    return;
                }

                setLoaded( next.file );

                
                var version = next.version ? (next.file.indexOf('?') === -1  ? '?' : '&') + 'v='+ next.version : '';

                getScript( next.file + version )

                    .done(function( /*script, textStatus*/ ) {
                        //log('.. load: ' + next.name);
                        loadModules( modules );
                    })

                    .fail(function( jqxhr, settings, exception ) {
                        log('Error loading module: ' + next.name);
                        log(next);
                        log(exception);
                    });

		    if(next.css){
			loadStyles(next.css, version);
		    }
            }

            if(conf && conf.modules){
                loadModules( conf.modules );
                
            } else {
                callback();
            }
        } //end load

        function loadModulesFile(modulesFile){

            var next = modulesFile.shift();

            if(!next){
                fireModuleLoad();                
                
                avantApp.fireLater('modulesLoad', avantApp);

                log('... load OK');
                
                return;
            }

            function decompressModules(raw) {

                function duplicateM(f, module){                                
                    
                    modules.push({
                        name: module.name + ':' + f,
                        css:  module.css || [],
                        file:f,
                        version: module.version
                    });

                    module.css = [];
                }

                var modules = [];
                
                raw.modules.forEach(function loopM(module){
                     
                    var js = module.js;
                    var file = module.file;
                                   
                    var m = {
                        name: module.name,
                        css: module.css || [],
                        version: module.version
                    };

                    if(Array.isArray(file) || Array.isArray(js)) {

                        if( Array.isArray(file) ) {
                            file.forEach(function(file){duplicateM(file, m);});
                        } else if(file) {
                            duplicateM(file, m);
                        }

                        if( Array.isArray(js) ) {                           
                            js.forEach(function(file){duplicateM(file, m);});
                        } else if(js) {
                            duplicateM(js, m);
                        }                        

                    } else {
                              
                        if(file) {
                           duplicateM(file, m);
                        }

                        if(js) {
                           duplicateM(js, m) ;
                        }
                    } 

                });

                return {
                    file: raw.file,
                    modules: modules
                };
            }

            $.ajax({
                url: next,
                cache:false,
                type:'GET',
                
                success: function( data ) {
                   
                    loadModulesFrom( data && data.modules ? decompressModules(data) : data, function(){
                        loadModulesFile(modulesFile);
                    });
                },

                error: function(){
                    log('Error loading modules file');
                }
            });


        } // end loadModulesFile

        $.ajax({
            url: conf,
            cache:false,
            type:'GET',
            
            success: function( data ) {
                config = data;
                config.loaded = true;
                
                fireModuleLoad();

                loadModulesFile(modulesFile);
            },

            error: function(){
                log('Error loading config');
            }
        });

    } //end loadModulesFile

    
    ///collect data

    function collectFromModules( what, initialValue ) {
	
	var funcName = 'collect'+ (what.substr(0,1) .toUpperCase()) + what.substr(1) ;
	    	    
	return _.reduce(_.values(modules), function(acc, module) {
			
		if(module[funcName] && _.isFunction(module[funcName])) {

                    var newValue = module[funcName](acc);

		    return newValue === null || newValue === undefined ? acc : newValue;			
		}
		
		return acc;
		
	}, initialValue);
	
    }

    //events segar
    function addModuleEventsAlias(modulesConf) {

        var found = _.filter(_.values(modulesConf), function(conf){ return conf.events;});

        var events = _.reduceRight(found, function(acc, conf) { return acc.concat(conf.events); }, []);

        var eventsAlias = {};

        events.forEach(function(what){
            var eventName = 'on'+ (what.substr(0,1) .toUpperCase()) + what.substr(1) ;

            eventsAlias[eventName] = function(handler) {
                avantApp.on(what, handler);
            };

        });
        
        return eventsAlias;
    }
    
    //api

    avantApp.init = function(conf, modules) {

        var js = _.map(document.getElementsByTagName('script'), function(e){ return e.src;  });
     
        js = _.filter(js, function(file){ return file.substr(0,4) === 'http'; });

        loadedFiles = _.map(js, function(url){
            return url.match('https?://([^/]+)/([^?]+)(.*)?')[2];
        });
        
        load(conf, modules); 
    };


    //////////// API
    createEventDispacher(avantApp);

    avantApp.createEventDispacher = createEventDispacher;

    avantApp.getConfig = function() { return config; };

    avantApp.getModules = function() { return modules; };

    avantApp.getModule = function(name){ return modules[name]; };

    avantApp.register = function(name, module, options){

        if(avantApp.getModule(name)) {
            log('Module ' + name + ' is already registered.');

            return avantApp;
        }

        registerModule(name, module);
        config._modules = config._modules || {};
        
        if(options){
            config._modules[name] = options;
        }

        var events = addModuleEventsAlias( config._modules );

        events.onLoad = function(callThis) {
                module._onLoad = callThis;

                fireModuleLoad(module); 

                return avantApp;
        };
        
        events.on = avantApp.on;

        return events;

    };
    
    avantApp.collect = collectFromModules;
    
    //error events:

    avantApp.fireError = function(msg, error){
        log(msg);
        log(error);

        avantApp.fire('error', {msg:msg, error:error});
    };
    
    //debug
    avantApp.sayHello = function(){ 
        log('Avantrip is up');       
    };


    //initial setup
    avantApp.register('Avantrip', avantApp, {
        events: ['load', 'moduleLoaded','modulesLoad'] 
    });
    
    avantApp.register('AvantripDebugInfo', {})
        .on('modulesLoad', function(){
            if(avantApp.getConfig().devMode) {
                log('Berazategui is on DEVELOPER MODE enabled.');
            }
        });

    return avantApp;

})();

Avantrip.sayHello();
