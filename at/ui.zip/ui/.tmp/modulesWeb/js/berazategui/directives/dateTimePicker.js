/* global Avantrip, moment*/
(function() {

    'use strict';


    function initDirectiveDateTimePicker(app) {
        /******************** DatePicker *******************/
        app.directive('hotelesDatetimepicker', [
            '$timeout',
            function($timeout) {

                var _format = 'YYYY-MM-DD HH:mm';

                return {
                    require: '?ngModel',
                    restrict: 'AE',
                    scope: {},
                    link: function($scope, $element, $attrs, controller) {

                        $element.on('dp.change', function() {
                            $timeout(function() {
                                var dtp = $element.data('DateTimePicker');
                                controller.$setViewValue(dtp.date());
                            });
                        });

                        function setPickerValue() {
                            var result = null;

                            if (!!controller && !!controller.$viewValue) {
                                result = moment(controller.$viewValue).format(_format);
                            }
                            var dtp = $element.data('DateTimePicker');
                            dtp.date(result);
                        }

                        controller.$render = function() {
                            setPickerValue();
                        };

                        $element.datetimepicker({
                            allowInputToggle: true,
                            format: _format,
                            sideBySide: true
                        });

                        setPickerValue();
                    }
                };
            }
        ]);
    }

    Avantrip.on('angularLoad', initDirectiveDateTimePicker);


})();