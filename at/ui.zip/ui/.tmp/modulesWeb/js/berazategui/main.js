/* global Avantrip, Konami, $ */
(function startApp() {

    'use strict';

//launch app
    Avantrip.init('config.json', ['modules.json']);

    // launch riqui

    document.bastaFort = function() {
      $('#fortPanic').remove();

      $('body').css('background-image', 'none');
    };

    document.daleFort = function() {
      $('body').css('background-image', 'url(/images/berazategui/ricardo.jpg)');

      var link = $('<a>')
                  .attr('href','#')
                  .append('Basta chicos!');

      $('#menu-list').append( $('<li>').attr('id','fortPanic').append( link ) );

      $( '#fortPanic' ).click(function() {
        document.bastaFort();
        return false;
      });
    };

    $(document).on('keyup',
        Konami.code(document.daleFort)
    );

})();
