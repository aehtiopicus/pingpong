/* global Avantrip, _ */
(function startApp() {

    'use strict';

    ///////////////////////////

    var api = {};

    api.gds = {};

    api.list = function() {
        return _.clone(api.gds);
    };

    Avantrip.register('gdsService', api)
        .onLoad(function(avantApp){

            avantApp.getModule('didadi').getCollection('gds',null, 
                function(response) {
                    api.gds = response; 
                },
                function(error) {
                    avantApp.fireError('gdsService: Error al cargar lista de GDS.', error);
                    api.gds = [];
                });
        })
    
        .on('angularLoad', function(app){
            
            app.factory('gdsList', function() {
                return api.list();
            });
            
        });
    

})();
