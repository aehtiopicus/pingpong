/* global Avantrip, _ */
(function startApp() {

    'use strict';

    ///////////////////////////

    var api = {};
    
    api.langs = [];

    api.list = function() {
        return _.clone(api.langs);
    };
    
    Avantrip.register('languageService', api, {
        events: ['languagesLoad']
    })
        .onLoad(function(avantApp){             
            avantApp.getModule('didadi').getCollection('languages', null, 
                function(response) {
                   api.langs = response; 
                },
                function(error) {
                    avantApp.fireError('languageService: Error al cargar lista de lenguajes.', error);
                    api.langs = [];
                }); 
        })    
        .on('angularLoad', function(app){
            app.factory('languageList', function() {
                return api.list();
            });
            
        })
        .on('modulesLoad', function(){
            Avantrip.fireLater('languagesLoad', api);
        });
    

})();
