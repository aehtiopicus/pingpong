/* global Avantrip */
(function startApp() {

    'use strict';

    ///////////////////////////

    var api = {};

    api.canAccess = function(module, action) {
        console.log('canAccess ' + action + ' ' + module);
        return true;
    };

    Avantrip.register('securityService', api)
        .onLoad(function(){
            
            
        })
    
        .on('angularLoad', function(app){            
            
            app.factory('security', function() {
                return api;
            });
            
        });
    

})();
