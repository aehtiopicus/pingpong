/* global angular, Avantrip, window */
(function startApp() {

    'use strict';

    ///////////////////////////


    var appName = 'avantripWebApp';


    //register
    function onAvtLoad(avt){
        var app = loadAngular(Avantrip);

        avt.fire('angularLoad', app);

        angular.bootstrap(window.document, [appName]);

    }

    Avantrip.register('angular', angular)
        .on('modulesLoad', onAvtLoad)
        ;


    ///////////////////////////

    function loadAngular(Avantrip) {

	var extras = Avantrip.collect('angularModules', [
                        'ngRoute',
                        'ui.bootstrap',
                        'ngSanitize',
                        'oi.select',
                        'cgNotify',
                        'ngDragDrop'
                        //'angularUtils.directives.dirPagination'
                        ]);

        var app = angular.module(appName, extras);

        // external
        app.factory('Avantrip', function() {
            return Avantrip;
        });

        app.factory('config', function() {
            return Avantrip.getConfig();
        });

        ///

        app.config(function($routeProvider) {

		Avantrip.register('routeProvider', $routeProvider)
                .onLoad(function(avt){
                    avt.fire('routeLoad', $routeProvider);
                });

        });

        return app;

    } //end loadAngular


})();
