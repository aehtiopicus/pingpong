/* global Avantrip, $, Spinner */
(function(){

    'use strict';

    var  UICtrl = {};

    UICtrl.selectBtn = function(id){
	$('.nav li').removeClass( 'active' );
	
	$('#'+id).addClass('active');
    };

    UICtrl.showLoading = function(){
        $('#loadingModal').modal({
          backdrop: 'static',
          keyboard: false,
          show: true
         });
    };

    UICtrl.hideLoading = function(){
        $('#loadingModal').modal('hide');
    };

    UICtrl.init = function(scope) {

        UICtrl.showError = function( msg, details) {
	    scope.currentError = {
	        title: msg || 'Error',
	        details: details || '' 
	    };

	    $('#errorModal').modal({
                show: true
            });
        };

        scope.$on('berazategui.error', function(event, args) {
                UICtrl.showError(args.msg, args.details);
         });
    };

    function loadAngular(app){

        app.controller('ErrorModalController', function($scope, UICtrl){
            UICtrl.init($scope);
        });
        
        app.factory('UICtrl', function() {
            return UICtrl;
        });
    }

    function init(){

        //spiner
        var opts = {
            lines: 13, // The number of lines to draw
            length: 20, // The length of each line
            width: 10, // The line thickness
            radius: 30, // The radius of the inner circle
            corners: 1, // Corner roundness (0..1)
            rotate: 0, // The rotation offset
            direction: 1, // 1: clockwise, -1: counterclockwise
            color: '#000', // #rgb or #rrggbb or array of colors
            speed: 1, // Rounds per second
            trail: 60, // Afterglow percentage
            shadow: false, // Whether to render a shadow
            hwaccel: false, // Whether to use hardware acceleration
            className: 'spinner', // The CSS class to assign to the spinner
            zIndex: 2e9, // The z-index (defaults to 2000000000)
            top: '50%', // Top position relative to parent
            left: '50%' // Left position relative to parent
        };

        new Spinner(opts).spin(document.getElementById('loadingSpin'));

        UICtrl.showLoading();
    }

    Avantrip.register('UICtrl', UICtrl)
        .onLoad(init)
        .on('modulesLoad', function(){

            Avantrip.fire('uiLoad', UICtrl); 
            
            setTimeout(UICtrl.hideLoading, 200);
        })
        .on('angularLoad', loadAngular);

})();
