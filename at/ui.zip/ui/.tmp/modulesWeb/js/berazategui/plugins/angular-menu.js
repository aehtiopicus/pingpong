/* global   Avantrip, _, $  */
(function startApp() {

    'use strict';

    var api = {};
	    
    var sections= {};

    function getExistentSection(section) {
	var targetSection = {};
	
	if( (typeof section) === 'object'  ){	
	    
	    if(sections[section.text]) {
		targetSection = sections[section.text];
	    }
	    
	    targetSection.text = section.text;
	    targetSection.url = section.url || '#'; 
	    targetSection.order = section.order; 		
	    
	} else if(sections[section]) {
	    targetSection = sections[section];
	} else  {
	    targetSection.text = section;
	    targetSection.url = '#'; 
	}
	
	return targetSection;
    }

    api.add = function(menu){
	 api.addMenu('Avantrip ABM', menu);
    };
    
    api.addMenu = function(section, menus){
       
	menus = menus.length ? menus : [menus];
	    
	var targetSection = getExistentSection(section);
	
	var existent = targetSection.menusByKey  || [];
	    
	_.each(menus || [], function(menu){
			existent[menu.url] = menu;
		});
	
	targetSection.menusByKey  = existent;
	targetSection.menus  = _.values(existent);
		
	sections[targetSection.text] = targetSection;
	    
    };
 
    api.get = function(){
	return _.sortBy(
			 _.values(sections), 
			function(sec){ return sec.order || 20; }
			);
    };
    
    
    Avantrip.register('menu', api)
	.on('modulesLoad', function(avt){
	      avt.fire('menuLoad', api);
             setTimeout(function(){$('#menu-list').show();}, 300);
	})
	.on('angularLoad', function(app){
            app.controller('menuController', function($scope){
		$scope.sections = api.get();
	    });
	    app.factory('uimenu', function() {
		return Avantrip.getModule('menu');
	    });
	});
})();
