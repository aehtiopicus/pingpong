/* global  Avantrip, _ */
(function initLangBox() {

    'use strict';

    var api = {
        selectedLanguage: null,
        selected: null

    };
 
    function initAngular(app){            
        
        app.factory('languageBox', function() {
            return api;
        });

        app.controller('LangBoxCntrl', function($rootScope, $scope, languageBox, languageList){

            $rootScope.$on('berazategui.languagesLoad', function(event, args) {
                $scope.langs = args.list();
            });

            $scope.langs = languageList;

            $scope.langBoxModel = _.find(languageList, function(l){return l.code === api.selectedLanguage;});

            $scope.$watch('langBoxModel', function(newVal){
                api.selected = newVal;
                Avantrip.fire('languageChange', newVal);
                
                $rootScope.langBox = {
                    selected: newVal
                };
            });

            Avantrip.fireLater('langBoxLoad', api);
        });
        
    }

    Avantrip.register('langBox', api, {
        events: ['langBoxLoad', 'languageChange']
    })
        .onLoad(function(){
            api.selectedLanguage = Avantrip.getConfig().defaults.language;
        })
	/*
        .on('languagesLoad', function(langApi){

        })  
	*/
        .on('angularLoad', initAngular);    

})();
