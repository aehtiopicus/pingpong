/* global Avantrip, DidadiClient */
(function initDidadi() {

    'use strict';

    var didadiClient = new DidadiClient();
	
    var ep = Avantrip.getConfig().didadiEndpoint;
	
    if(ep) {
        didadiClient.setURL(ep.host + ':' + ep.port);
    }
    
    Avantrip.register('didadi', didadiClient)
        .on('modulesLoad', function(/*avt*/){

        });    

})();
