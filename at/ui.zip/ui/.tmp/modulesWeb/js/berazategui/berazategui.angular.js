/*! berazategui - v1.74.0 - 2016-04-21\\n  * Copyright (c) 2016  Avantrip; Licensed  */(function() {

Avantrip.register('mainAngularApp', {})
		.on('loadMainAngularComponents', 
                                    function(angularApp) {
                                               loadAngularComponents(angularApp, Avantrip.getConfig())
                });


function loadAngularComponents(angularApp, mainConfig) {



(function(){

    'use strict';

  /*  //deprecate warnings
  function disableWarnings($provide) {
    $provide.decorator('$tooltipSuppressWarning', function () { return true; });
    $provide.decorator('$modalStackSuppressWarning', function () { return true; });
    $provide.decorator('$modalSuppressWarning', function () { return true; });
  }
  */

	angular
		.module('berazategui.controllers')
    //.run(disableWarnings)
		.controller(
				'BerazateguiMainController',
				function() {

					// add some logic

				});

})();



}; //end angular wrapper

})();
