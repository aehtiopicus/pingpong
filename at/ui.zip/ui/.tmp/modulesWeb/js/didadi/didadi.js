
/**
* DidadiClient js client

        API:
         var dd = new DidadiClient("http://localhost:8080");
         dd.getCollections(successFn, errorFn) 
         dd.get(path, successFn, errorFn)
         dd.getCollection(collectionName, filter, successFn, errorFn) 
         dd.setURL(endpoint) 
*/
function DidadiClient(endpoint) {

    'use strict';

    var URL = endpoint || "http://localhost:8080",  GET = "GET";

    function request(method, path, successFn, errorFn) {

        $.ajax({
            url: path,
            type: method,
            success: successFn,
            error: errorFn
        });
    }

    this.getCollections = function (successFn, errorFn) {
        request(GET, URL, successFn, errorFn);
    };

    function get(path, successFn, errorFn) {
        request(GET, URL + '/' + path, successFn, errorFn);
    }

    this.getCollection = function (collectionName, filter, successFn, errorFn) {
        var filterStr = '';

        if (filter && !$.isEmptyObject(filter)) {
            filterStr = '?filter=' + JSON.stringify(filter);
        }

        get(collectionName + filterStr, successFn, errorFn);
    };

    this.setURL = function (url) {
        URL = url;
    };

    return this;
}