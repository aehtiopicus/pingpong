
// Make sure code styles are up to par and there are no obvious mistakes

module.exports = function(grunt) {
    return {
        jshint: {
            options: {
                jshintrc: '.jshintrc',
                reporter: require('jshint-stylish')
            },
            all: [
                'Gruntfile.js',
                '<%= berazategui.options.app %>/scripts/**/*.js',
	        '<%= berazategui.options.app %>/angular/**/*.js',
                'test/spec/{,*/}*.js',
		'<%= berazategui.options.app %>/grunt/tasks/**/*.js',
                '<%= berazategui.options.app %>/grunt/Gruntfile.js',
		'<%= berazategui.grunt.master %>/**/*.js',
                'lib/**/*.js'
            ]
        }
    };

};
