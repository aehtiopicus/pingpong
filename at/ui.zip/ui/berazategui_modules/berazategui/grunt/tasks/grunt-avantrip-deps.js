'use strict';

module.exports = function (grunt, globalconfig) {
    var config = (globalconfig || {}).avantripDeps || {};

    var request = require('request'),
        fs = require('fs'),
        merge = require('object-merge'),
        async = require('async'),
        crypto = require('crypto'),
        tarball = require('tarball-extract'),
        unzip = require('unzip')
            ;

    //base
    var options = merge(
            {
                server: 'http://nexus.devtrip.com.ar/',
        repo: 'releases',
        version: 'LATEST'

            }, config.options || {});

    // get file from nexus
    var fetchFile = function(options, cback) {

        grunt.log.writeln('fetchFile: ' + options.group+ ':' + options.artifact);
        var extension = (options.extension ? options.extension : 'tgz');

        var url = options.server + 'service/local/artifact/maven/redirect?r=' + 
            options.repo + '&g=' +
            options.group+ '&a=' +
            options.artifact  + '&v=' +
            options.version + '&e=' +
            extension;

        var filename = '.tmp/bzmodules/bzm_' + options.artifact + '_' + crypto.randomBytes(8).readUInt32LE(0) + '.' + extension;

        var stream = fs.createWriteStream(filename);

        var onError = function(err) {
            cback('file error -> ' + err);
        };

        stream
            .on('error', onError)
            .on('close', function() {
                grunt.log.ok('get - ok --> ' + options.group + ':' + options.artifact+' ok');

                if(extension.toLowerCase() === 'zip') {
                    //zip
                    var unzipExtractor = unzip.Extract({ path: options.to });
                    unzipExtractor.on('error', onError);
                    unzipExtractor.on('close', function() { 
                        grunt.log.ok('unzip - ok --> ' + options.group + ':' + options.artifact+' ok');
                        cback(); 
                    });

                    fs.createReadStream( filename ).pipe(unzipExtractor);

                } else {
                    //tgz
                    tarball.extractTarball(filename, options.to, function(err){
                        if(err) { 
                            onError(err);
                        } else {
                            grunt.log.ok('tgz - ok --> ' + options.group + ':' + options.artifact+' ok');
                            cback(); 
                        }
                    });
                }


            });


        request( url ).pipe( stream );


    };

    grunt.registerTask('avantripDeps', ['avantrip-deps']);

    /**
      Tareas grunt
      */
    grunt.registerTask('avantrip-deps', 'Tareas core avantrip.', function() {

        var done = this.async();

        var modulesdir = globalconfig.berazategui.modules.path;

        grunt.file.mkdir( '.tmp/bzmodules' );
        grunt.file.mkdir( modulesdir );    

        if ( config.deps ){

            var forEveryItem = function(item, callback) {

                var target = merge(options, item);

                target.to = modulesdir+'/'+item.name;

                fetchFile(target, function(error){

                    if(error) {
                        grunt.fail.warn(error);
                        callback(false);
                    }

                    callback(true);
                });

            };

            //fetch all
            async.every(config.deps, forEveryItem, done); 

        } else {
            done();
        }



    });

};
