'use strict';

/**
* version task
*/
module.exports = function (grunt) {
    /**
      Tareas grunt
    */
    grunt.registerTask('versioning', 'Tareas de versionado.', function( type, action ) {

	var oldVersion = grunt.file.readJSON('package.json').version;
	    
        var version = oldVersion.split('.');

        version = {
            major: version[0] || 0,
            minor: version[1] || 0,
            patch: version[2] || 0
        };
	
        var actions ={
            increment: function(type, version) {
		if(type==='major') {
		    version.mayor = parseInt(version.mayor)+1;
		    version.minor = 0;
		    version.patch = 0;
		    
		} else if(type==='minor') {
		    version.minor = parseInt(version.minor)+1;
		    version.patch = 0;
		} else {
		    version.patch = parseInt(version.patch)+1;
		}
		
            },
	    none: function() {},
	    refresh: function() {}
        };

        actions[action || 'none'](type, version);

        version = '' + version.major + '.' + version.minor + '.' + version.patch;

	grunt.log.ok( 'new version: ' + version + ', previus: ' +  oldVersion );
        
	grunt.task.run('bumpup:' + version);


    });
    


};
