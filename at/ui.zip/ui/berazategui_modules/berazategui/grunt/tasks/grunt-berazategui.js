'use strict';

var _ = require('underscore');
var path  = require('path');

////////////////////////////////

var dirs = {
    tmpWeb: '.tmp/modulesWeb/',
    tmpConf: '.tmp/configs/',
    tmpExport: '.tmp/export/',
    tmpWebExport: '.tmp/export/web/',
    tmpCss: '.tmp/styles/'
};

////////////////////////////////

/*helper*/
function mergeFiles( options, mergeFnc ) {

    var grunt = options.grunt;

    var confDir = options.globals.berazategui.srcDir + options.srcDir;
    var configsFiles = grunt.file.expand( confDir + '/' + options.srcExtension );

    var depsDir = options.globals.berazategui.modules.path;
    var modules = grunt.file.expand( depsDir + '/**' + options.srcDir + '/' + options.srcExtension );

    var allConfigs = [];

    //load
    modules.concat(configsFiles).forEach(function(file){
        var conf = grunt.file.readJSON(file);
        conf.order = conf.order || 1;
          
        allConfigs.push( conf );

    });

    //merge
    var configuration = {};

    _.sortBy(allConfigs, function(c){ return c.order; })
        .forEach(function(c){
            configuration = mergeFnc(c, configuration);
        });

    delete configuration.order;

    grunt.file.write(options.out, JSON.stringify(configuration, null , 4 ));

    return configuration;
}

/*helper */
function copyDir(grunt, src, to) {
    grunt.file.recurse(src, function callback(abspath, rootdir, subdir, filename) {    
        grunt.file.copy(abspath, to + path.sep + (subdir ? subdir + path.sep : '')  + filename );
    });
}


////////////////////////////////

/**
 find js and create config file
*/
function createModulesFile( options ) {

    var grunt = options.grunt;

    //config
    var src = options.globals.berazategui.srcDir ;
    var appName = options.globals.pkg.name;
    var appFile = appName+'.generated.modules.json';
    var libFile = appName+'.generated.libs.modules.json';
    var version = options.globals.pkg.version;

    //clean
    grunt.file.delete( src + '/configs/' + appFile);
    grunt.file.delete( src + '/configs/' + libFile);

    ///

    var config = {
        order: 1,
        file: appFile,
        modules: []
    };

    //general files
    config.modules.push({ 
        name: appName + '-standar-files',
        js: [
            'js/'+appName+'/'+appName+'.angular.js'
        ],
        css:[
            appName + '.compliled.styles.css', 
            appName + '.styles.css'
        ],
        version: version,
        appCode: appName
    });

    //find js
    var alljs = grunt.file.expand( {cwd:src + '/scripts/'}, '{,*/}*.js' );

    alljs = _.map(alljs, function(p) {
        return 'js/'+appName+'/'+p;
    });

    //get existent configs

    var existent = [];
    grunt.file.expand( src + '/configs/*.modules.json' ).forEach(function(f){
        
        (grunt.file.readJSON(f).modules || []).forEach(function(module){
            if( module.file ) {
                existent.push(module.file);
            }
            
            if( module.js ) {
                existent = existent.concat( module.js );
            }
        });
        
    }); 

    //filter:
    alljs = _.filter(alljs, function(j){ return !_.contains(existent, j); } );

    //sdks
    var depsDir = options.globals.berazategui.modules.path;

    var libs = _.map(grunt.file.expand({filter:'isDirectory', cwd:depsDir}, '*' ), function(module){
        var bowerConf = depsDir+'/'+module+'/bower.json';
        //is a library
        if( grunt.file.exists( bowerConf ) ) {
            bowerConf = grunt.file.readJSON(bowerConf);

            if(bowerConf.main) {
                return _.map(bowerConf.main,function(f) {
                    return 'js/'+module+'/'+f;
                });
            } else {
                return [];
            }
            
        } else {
                return [];
            }
    });

    if(alljs.length !== 0) {
        config.modules.push({ 
            name: appName + '-app-files',
            js: alljs,
            version:version,
            appCode: appName
        });
    }

    grunt.file.write( src + '/configs/' + appFile, JSON.stringify(config, null , 4) );
    
    config = {
        order: -2,
        file: appFile,
        modules: []
    };

    if(libs.length !== 0) {
        config.modules.push({ 
            name: appName + '-lib-files',
            js: _.flatten(libs),
            version:version,
            appCode: appName
        });
    }

    //save
    grunt.file.write( src + '/configs/' + libFile, JSON.stringify(config, null , 4) );
}

/**
* join web content
*/
function joinWebs( options ) {

    var grunt = options.grunt;

    var depsDir = options.globals.berazategui.modules.path;

    //fetch webs
    var modulesArray = grunt.file.expand( depsDir + '/*/web' );
    var index = modulesArray.indexOf(depsDir + '/berazategui/web');
    if (index > -1){
        modulesArray.splice(index,1);
        modulesArray.push(depsDir + '/berazategui/web');
    }

    modulesArray.forEach(function(w){
        copyDir(grunt, w, dirs.tmpWeb);
    });
    
    //fetch libs
    modulesArray = grunt.file.expand({filter:'isDirectory', cwd:depsDir}, '*' );
    index = modulesArray.indexOf('berazategui');
    if (index > -1){
        modulesArray.splice(index,1);
        modulesArray.push('berazategui');
    }    

    modulesArray.forEach(function(module){
        var bowerConf = depsDir+'/'+module+'/bower.json';
        //is a library
        if( grunt.file.exists( bowerConf ) ) {
            bowerConf = grunt.file.readJSON(bowerConf);

            //copy all files
            if(bowerConf.main) {
                bowerConf.main.forEach(function(f) {
                    var src =  depsDir+'/'+module+'/'+f;
                    var to =  dirs.tmpWeb + '/js/'+module+'/'+f;
                    grunt.file.copy(src, to);
                });
            }           

        }
    });
    
}

/**
 build modules
*/
function mergeModules( options ) {

    options.srcDir = '/configs';
    options.srcExtension = '*.modules.json';
    options.out = dirs.tmpConf + 'modules.json';

    mergeFiles( options, function(c, acc) {

        var all = (acc.modules || [] ).concat( c.modules || [] );
        
        acc.modules = all;

        return acc;
    } );
}

/**
* configs
*/
function mergeConfigs( options ) {
    
    options.srcDir = '/configs';
    options.srcExtension = '*.config.json';
    options.out = dirs.tmpConf + 'config.json';

    mergeFiles( options, require('object-merge') );
}

function applyCurrentVersion(options){

    var grunt = options.grunt;

    var src = options.globals.berazategui.srcDir ;
    var appName = options.globals.pkg.name;
    var version = options.globals.pkg.version;

    grunt.file.expand( src + '/configs/*.modules.json' ).forEach(function(f){

        var file = grunt.file.readJSON(f);

        (file.modules || []).forEach(function(module){
            module.version = version;
            module.appCode = appName;
        });

        grunt.file.write( f, JSON.stringify(file, null , 4) );
        
    });

    var versionInfo = {
        version: version,
        buildDate: new Date(),
        appCode: appName
    };

    var save = {};
    save[appName+'-version'] = versionInfo;

    grunt.file.write( src + '/configs/'+appName+'.version.config.json', JSON.stringify(save, null , 4) );
}

////////////////////////////////


module.exports = function (grunt, options) {
    options = options || {};

    /**
     Tareas grunt
     */
    grunt.registerTask('berazategui', 'Tareas core del framework.', function(action) {

        if(!action) {
            grunt.fail.warn('No se especifico tarea');
            return false;
        }

        //declare actions
        var actions = {
           'modulesFile': createModulesFile,
           'mergeConfigs': mergeConfigs,
           'mergeModules': mergeModules,
           'joinWebs': joinWebs,
           'applyVersion': applyCurrentVersion
            
        };

        //exec all?
        if( action === 'glue' || action === 'all' ) {

            var all = _.map(_.keys(actions), function(a){
                return 'berazategui:' + a;
            });
            
            grunt.task.run( all );

            return true;
        }

        //select action
        var exec = actions[action];
        
        if (!exec) {
            grunt.fail.warn('No existe la tarea: '+ action);
            return false;

        } else {

            var params = {
                taskObjt: this, 
                grunt: grunt, 
                options: this.options(), 
                globals: options
            };

            exec( params );
        }

        return true;

    });
    

};


