'use strict';

/** load all configs */
function makeConfig(grunt, berazateguiConf) {	
    var merge = require('object-merge');
	
    var initconfig = require('grunt-initconfig/tasks/initconfig')(grunt);

    var globalconf = initconfig.readAndMerge({
        cwd: berazateguiConf.grunt.masterConf,
        files: '**/*.{json,yaml,js}'
    });
 
    var customconf = initconfig.readAndMerge({
        cwd: berazateguiConf.grunt.customConf,
        files: '**/*.{json,yaml,js}'
    });
    
    var conf = merge( globalconf, customconf );
    
    berazateguiConf.distDir =  berazateguiConf.distDir || berazateguiConf.options.dist;
    berazateguiConf.webDist =  berazateguiConf.webDist || berazateguiConf.distDir + '/web';
    
    berazateguiConf.srcDir =  berazateguiConf.srcDir || berazateguiConf.options.app;
    
    berazateguiConf.tmpApp =  berazateguiConf.options.devapp || '.tmp/webapp';
    
    conf.berazategui = berazateguiConf;
    
    return conf;
}

/* load exposted tasck */
function loadSharedTasks( grunt, conf ) {
    //fin custom tascks

    var appDir = conf.berazategui.options.app;
    var modules = conf.berazategui.modules.path;

    var loadT = function(path) { 
        //load
        require( '../../'+ path )(grunt, conf);
    };

    //find tasks in modules
    grunt.file.expand('lib/tasks/{,*/}*.js').forEach(loadT);
    grunt.file.expand( appDir + '/grunt/tasks/{,*/}*.js').forEach(loadT);
     
    // imported
    grunt.file.expand(modules + '/*/grunt/tasks/*.js').forEach(function(path) { 
        //load
        require( '../../../'+ path )(grunt, conf);
    });
}

/*global module:false*/
module.exports = function(grunt, berazateguiConf) {
    var merge = require('object-merge');

    //default values
    berazateguiConf = merge({
        modules: {
            path: 'berazategui_modules'
        },        
	options:  {
		app: 'app',
		dist: 'dist',
		devapp: '.tmp/webapp'
	}
    }, berazateguiConf);

    // Load grunt tasks automatically
    require('load-grunt-tasks')(grunt);

    // Time how long tasks take. Can help when optimizing build times
    require('time-grunt')(grunt);

    //configs
    var conf = makeConfig(grunt, berazateguiConf);
	
    grunt.initConfig( conf );

    loadSharedTasks( grunt, conf );
 
    //tasks    
    grunt.registerTask('serv', ['run'] );
   
    grunt.registerTask('core-compile', ['default'] );
    
    grunt.registerTask('core-default', ['clean', 'jshint', 'tmp-web'] );
    
    grunt.registerTask('core-tmp-web', ['core-configs', 'core-styles', 'copy:tmp-web', 'berazategui:joinWebs'] );

    grunt.registerTask('core-styles', ['less', 'concat:less', 'concat:styles'] );

    grunt.registerTask('core-configs', [ 
        'berazategui:modulesFile', 
        'berazategui:mergeConfigs', 
        'berazategui:mergeModules',
        'berazategui:applyVersion',
        'concat:angular',        
        'bowercopy:tmp-web'
    ] );

    grunt.registerTask('core-package', [
        'default',
        'copy:collectconf',
        'copy:dist',
        'bowercopy:dist'
    ] );

    grunt.registerTask('core-test', function(target) {
	    
        if (target !== 'watch') {
            grunt.task.run([
                'clean:server',
            ]);
        }

        grunt.task.run([
            'connect:test',
            'mocha'
        ]);
    });
    
    
    grunt.registerTask('core-run',  function (target) {
	    
        if (target === 'dist') {
            return grunt.task.run(['package', 'connect:dist:keepalive']);
        }

        return grunt.task.run([
	    'newer:jshint',
            'tmp-web',
            'connect:livereload',
            'watch'
        ]);
    } ); 

    grunt.registerTask('core-export', [
        'clean',
	'package',
        'copy:export',
        'copy:custom-export',
//      'zip:export'
        'compress'
    ] );
    
    grunt.registerTask('core-deploy', ['test', 'versioning:refresh', 'export', 'nexusDeployer:snapshot']);
    
    grunt.registerTask('deploy-stable', ['versioning:minor:increment','deploy', 'nexusDeployer:release']);

    
};
