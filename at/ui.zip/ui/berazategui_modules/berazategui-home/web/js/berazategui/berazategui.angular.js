/*! berazategui - v1.14.0 - 2014-09-16\\n  * Copyright (c) 2014  Avantrip; Licensed  */(function() {

Avantrip.register('mainAngularApp', {})
		.on('loadMainAngularComponents', 
                                    function(angularApp) {
                                               loadAngularComponents(angularApp, Avantrip.getConfig())
                });


function loadAngularComponents(angularApp, mainConfig) {



(function(){

    'use strict';

	angular
		.module('berazategui.controllers')
		.controller(
				'BerazateguiMainController',
				function() {
				
					// add some logic
					
				});

})();


}; //end angular wrapper

})();
