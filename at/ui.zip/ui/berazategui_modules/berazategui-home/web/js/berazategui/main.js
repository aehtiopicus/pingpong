/* global Avantrip */
(function startApp() {

    'use strict';

//launch app
    Avantrip.init('config.json', ['modules.json']);

})();
